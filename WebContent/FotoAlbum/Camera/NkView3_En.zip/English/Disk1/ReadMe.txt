Thank you for purchasing a Nikon Coolpix digital camera. We are sure that 
it will give you many hours of reliable and productive use. 

Please note that the advanced operating information for your Coolpix digital 
camera is located on the Nikon Reference CD in the directory named PDF. 

The camera manuals are viewed by using the Adobe Acrobat reader, which is 
also included on the Nikon View reference CD. 

If you cannot open the manual files, please install the Adobe Acrobat reader 
to your hard disk. You may print the entire manual, or just the pages you are 
interested in at any time.

If you have difficulty printing the manual, reduce the number of pages you 
are printing at one time. Restarting your printer may free up additional 
printer memory to process the manual pages.

Please read the following important information, which was not included in 
the manual.

For viewing images taken with your Coolpix digital camera, you have two choices: 
1) You can remove the Compact Flash (CF) card from the camera and use a CF card 
reader or AT Card reader with a CF to AT adapter to read the card directly on 
your computer.
2) You can connect the camera to your computer using the serial interface and 
an appropriate cable. 

Either way, the Nikon View Ver.3 software will mount the CF Card or the camera 
on your computer, and allow you to browse the thumbnail images and to open 
the full size images. 

1. Tips

1.1. Nikon View Ver.3 supported cameras 
Nikon View Ver.3 supported cameras are as followings. No other Nikon digital 
cameras are supported. You can only have one camera connected at a time.

        Nikon DIGITAL CAMERA E990
        Nikon DIGITAL CAMERA E950
        Nikon DIGITAL CAMERA E800
        Nikon DIGITAL CAMERA E700
        Nikon DIGITAL CAMERA E900/E900s

1.2. Time required displaying thumbnails in a window
The amount time it to display thumbnail images in Nikon View Ver.3 window is directly 
related to the amount of data on your camera memory card. The more images on the memory 
card, the longer the mounting operation will take.

1.3. TWAIN
Please take note that Nikon View Ver.3 is not a "TWAIN source" and is not 
available under the TWAIN interface selector of any software application. 
Nikon View Ver.3 uses "drag and drop" to move files from the Nikon View Ver.3 
browser window to your hard disk or third party application. Move files from 
your Nikon View Ver.3 browser window to any application that supports drag and 
drop using the same method you would use to move files from one directory to 
another on your hard disk. You may also copy images from the Nikon View Ver.3 
and then paste them into an open document in your imaging application.

1.4 Testing scanners and cameras
When you use Windows 98 or Windows 2000, you have test function in the 
"scanners and cameras" in the properties page. However it will not perform 
hardware tests of Nikon Digital Cameras.

1.5. Installing the USB driver on Windows 2000 
When you start Windows 2000 with Coolpix 990 connected with the USB port 
for the first time, Windows 2000 will recognize the Coolpix 990 and automatically 
starts to install required USB drivers in your system.
During this installation, Windows 2000 may report "Digital Signature Not Found" 
and "There is no guarantee that this software works correctly with Windows. ".
Please press the "Yes" button in this case.

1.6. Limitations for image files created by the D1 camera 
If images that had been captured by the D1 are on the CF card and you put the 
card in the Coolpix camera, Nikon View Ver.3 may not display NEF or / and TIFF 
images depending on the conditions.
When you use the USB port Nikon View Ver.3 does not display NEF and TIFF images 
that had been taken by D1.
When you use the serial port; Nikon View Ver.3 will not display NEF or / and TIFF 
images that had been taken by the D1 camera and this may cause a communications 
error or the files might be invisible even the camera successfully mounted.

1.7. Temporary files
Every time when you open full resolution images using Nikon View, it creates 
temporary files under following locations;

Windows 95 or 98: \Windows\Temp\Camexp\Transfer
Windows NT4.0: \Temp\Camexp\Transfer
Windows 2000: \Documents and Settings\[User name]\LocalSettings\Temp\Camexp\Transfer
Please delete those temporary files frequently to avoid using significant 
amounts of disk space.

1.8. Serial Port Conflicts
Other devices and software may prevent the proper operation of the Nikon View 
software. Software for fax modems Personal Digital Assistants and for Windows CE 
devices may take control of the serial port and not release the port for the use 
of Nikon View. Please take the appropriate steps to assure that the serial ports 
on your system are not in use by other software before attempting to use Nikon View. 
In some cases the serial ports on your PC may not be active. This is most common 
on laptop computers with internal modems. If you cannot resolve serial port 
difficulties on a new PC or a laptop PC, check the system bios to determine if 
the serial ports are active. When you first start your system, there will be a 
notice on the screen that indicates the Bios version of your PC and the proper 
key to press to enter setup mode. Please consult your system documentation for 
the appropriate steps to take. Please note that making changes in the system bios 
may prevent your PC from booting.

IBM Thinkpad(TM) series laptops use a special utility called "Thinkpad Tools" to 
configure the system bios and serial ports. Your PC may also use a special  program 
to access the bios settings. It is most important to consult your hardware documentation.

IBM Thinkpad systems sold prior to 1998 may require a bios and driver update before 
the internal PC card readers will recognize a Compact Flash Card. Make note of 
the IRQ and I/O address space used by your serial ports when you are in the 
system bios. The support staff will require this information in order to assist 
you in resolving a port conflict. In all cases the serial port settings in your 
operating system MUST match those in the system bios, or the serial port will not 
operate properly.

1.9. Removal of Serial cable and/or CF Card from the camera
You must close Nikon View window and switch the camera off before you remove the 
serial cable and/or CF Card from your camera.

1.10. Share DLL files
There are files called DLL files. Those files can be shared with multiple programs. 
For example, a file called example.dll that is used by Nikon View Ver.3 may be used 
by some other Nikon programs and even non-Nikon programs such as image editing 
application software.
If the Nikon View installer finds such dll files during installation and those dll 
files are older versions than the Nikon View installer has, the Nikon View installer 
will backup those files and then over write the originals with newer version of dll 
files.
Those back up files should be made in the following folder or if you specified it in 
the installer, another location.
\Program Files\Nikon\NkView\LeadTools
Following files may be backed up:
	Ltfil10n.dll, Ltkrn10n.dll, Lfbmp10n.dll, Lfcmp10n.dll, Lffax10n.dll, Lftif10n.dll
	Ltdis10n.dll
When you find any problem after installing Nikon View Ver.3 with any other image 
application, especially when the application program attempt to draw images on the 
screen, the installer operation mentioned above might be the reason.
This means that the application that has the problem may require one or more older 
version of those dlls. If you are comfortable troubleshooting such a problem, please 
try to put those file back into the system folder one by one until the problem is 
solved, or call Nikon digital product hot line. Please make detailed notes of the 
applications involved, and the exact text of any error message launching applications 
after installing Nikon View Ver.3 before calling for assistance.

1.11. Installing Nikon View DX after installing Nikon View Ver.3
When you had already installed Nikon View Ver.3, you will get an error message that 
tell you "Could not start un-installer..." when you attempt to install 
Nikon View DX version 1.02 or older.
Please uninstall Nikon View Ver.3 and install Nikon View DX. After completion of 
Nikon View DX installation, please install Nikon View Ver.3 again.

1.12. Bundled software packages
This CD-ROM includes some bundled software packages. Please contact the companies 
supplying the bundled software for technical support for that particular product. 
Nikon does not provide any technical support for these software packages.

2. New features of Nikon View Ver.3

2.1. Deleting folder in the CF card in the camera
You can delete folders in the CF card in the camera when you are mounting the camera 
to your computer.
When you use the serial port and delete all folders, on folder called "100NIKON" will 
be created in the card automatically.
You cannot erase the folder called "IM01E900" when you Coolpix 900.

2.2. Copying folders
You can copy whole folder from a CF card in the camera to your hard disk.
Also you can copy the Nikon camera icon to your hard disk to copy all images you have 
in the camera.

3. Known problems

3.1. Changing the settings of "Address bar"
On Windows 95 or Windows 98/NT with Internet Explorer 4.0 , changing the location of 
the "Address bar" will cause an error to occur.

3.2. Opening multiple Thumbnail Windows/List View windows.
You should not open the multiple thumbnail windows /list view windows at the same time 
with this release of Nikon View Ver.3.

3.3. Windows Media player
Movie files that are captured by Coolpix 990 cannot be played with the Windows Media 
player software. Please use the QuickTime(TM) software that comes with Nikon View Ver.3.

3.4. Drivers supported by Windows 2000
Windows 2000 has "scanner and camera" drivers which includes drivers for Coolpix 700, 
Coolpix 900 and Coolpix 950. Those drivers are TWAIN drivers that allow you to import 
images from those cameras to a TWAIN compatible software.
After you install Nikon View Ver.3, those TWAIN drivers will not operate while 
Nikon View Ver.3 is running.

3.5. Opening more than one Nikon View windows
If you have problem when you open multiple Nikon View windows, please do not use more 
than two windows at the same time.

3.6. Opening a Nikon View window
Nikon View does not open a window automatically when you connect Coolpix 990 using the 
USB port, when you are using Nikon Capture.
Please double click the Nikon View icon that is displayed in the "my computer".

3.7. Cancel during a folder copy
When you cancel copying a folder from the camera, no images will be copied to the 
destination folder.

3.8. Turning off your Coolpix camera
Please make sure all thumbnails have disappeared from a Nikon View Ver.3 window when 
you switch off the camera power before you close the Nikon View windows.

3.9. Deleting an empty folder
Deleting an empty folder may not work properly when you use a serial port.

3.10. Deleting a folder when using Coolpix 700
Deleting a folder may not work properly when you use Coolpix 700 with Nikon View Ver.3.
Please use the camera internal functions to delete folders.

3.11. Browsing with Windows Explorer
When you use Windows Explore to browse thumbnails, thumbnail view may not displayed 
correctly when you move to a parent folder before Nikon View finishes to draw all 
thumbnails in the Explore window.


4. Software Versions
The following files are included in Nikon View Ver.3;
 
	MLCamView.dll		3.0.1.2
        Diacfldr.dll		3.0.1.1
        Diac_Res.dll		3.0.1.1
	Divadx2.dll		3.0.1.1
	Nkview2.dll		3.0.1.1
	EvLstnr.exe		3.0.1.1

	Esp_Mod.dll		1.6.1.3001
	Esp_Drv.dll		1.2.0.3005
	
	Nkdusb.dll		1.0.0.3000
	nkdusd.dll		1.0.0.3000
	Clpx_usb.md3		1.0.0.3005

	D1_Drv.dll		1.1.0.3001
	D1_Mod.md3		1.1.0.3003
	NkD1394p.dll		1.0.0.3000
	nk1394p.sys		1.0.0.3005

	ImgLibLead.dll		3.0.1.1

	Lfbmp10n.dll		10.0.0.022
	Lfcmp10n.dll		10.0.0.022
	Lffax10n.dll		10.0.0.018
	Lftif10n.dll		10.0.0.022
	Ltfil10n.dll		10.0.0.022
	LTDIS10N.dll		10.0.0.023
	Ltkrn10N.dll		10.0.0.021

	Nikon YCC TIFF.8BI	1.0.0.3001

Adobe is a registered trademark, and Photoshop is a trademark, of Adobe Systems Inc.
Apple, Macintosh, and FireWire are registered trade-marks of Apple 
Computer, Inc. Power Macintosh is a trademark of Apple Computer, Inc.
CompactFlash is a trademark of SanDisk Corporation.
Windows is a trademark of Microsoft corporation.
Internet Explorer is a product of Microsoft corporation.
All other brand or product names mentioned in this manual are the 
trademarks or registered trademarks of their respective holders.

March 15, 2000
