
/****************************************************************************
** DeeEnEs - Automatic Dynamic IP Updater
** Copyright (C) 2000, 2001, 2002, 2003, 2004 Tako Schotanus
** 
** This program is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License
** as published by the Free Software Foundation; either version 2
** of the License, or (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
****************************************************************************/

#define PROT_DYNDNS_OLD				1
#define PROT_DYNDNS_NEW				2

#define SIZE_OLDSERVERNAMES			11
#define SIZE_SERVICES				4
#define SIZE_SERVERS				47
#define SIZE_WEBIPDETECTORS			3

#define SCETF_OFFLINE_DONATORS_ONLY	1

struct DNSServicesType {
	char *szName;
	char *szHost;
	int nPortNr;
	char *szRequest;
	char *szOfflineRequest;
	int nProtocol;
	char *szNewHostURL;
	long lFlags;
};

#define SRVTF_DONATORS_ONLY			1
#define SRVTF_CUSTOM_DOMAIN			2

struct DNSServersType {
	char *szName;
	DNSServicesType *aService;
	int nFlags;
};

typedef struct DNSServersType SERVINFO;

struct WebIPDetectorType {
	char *szName;
	char *szHost;
	int nPortNr;
	char *szRequest;
};


extern struct DNSServicesType DNSServices[];
extern struct DNSServersType DNSServers[];
extern struct WebIPDetectorType WebIPDetectors[];
extern char *szOldDNSServerNames[];