
/****************************************************************************
** DeeEnEs - Automatic Dynamic IP Updater
** Copyright (C) 2000, 2001, 2002, 2003, 2004 Tako Schotanus
** 
** This program is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License
** as published by the Free Software Foundation; either version 2
** of the License, or (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
****************************************************************************/

#include <string>
#include <list>

using namespace std;

struct StringInfo {
	LPCSTR text;
	int size;
};

union NumOrStr {
	long *pl;
	short *pw;
	char *pb;
	StringInfo s;
};

union DefNumOrStr {
	long l;
	short w;
	char b;
	LPCSTR s;
};

enum PropertyType {
	PT_STRING,
	PT_NUMBER64,
	PT_NUMBER32,
	PT_NUMBER16,
	PT_NUMBER8
};

struct PropertyInfo {
	string			sSubItem;
	string			sName;
	PropertyType	nType;
	NumOrStr		Data;
	DefNumOrStr		Default;
};

typedef list<PropertyInfo> LISTPROP;

#define PB_OK				0
#define PB_MISSING_KEYS		1
#define PB_ERROR			-1

class PropertyBag {

protected:
	string m_sCompanyName, m_sAppName;
	LISTPROP m_bag;
	HKEY m_hRoot;

	const string getAppRegKeyStr(string sSubItem = "");
	UINT findAppBaseKey(PHKEY lphKey, string sSubItem = "");
	UINT getAppBaseKey(PHKEY lphKey, string sSubItem = "");

public:
	// Constructors & destructors
	PropertyBag(LPCSTR szAppName);
	PropertyBag(HKEY hRoot, LPCSTR szAppName);
	PropertyBag(LPCSTR szCompanyName, LPCSTR szAppName);
	PropertyBag(HKEY hRoot, LPCSTR szCompanyName, LPCSTR szAppName);
	~PropertyBag();

	// Property "Root" r/w
	void PropertyBag::setRoot(HKEY hRoot);
	HKEY PropertyBag::getRoot();

	// Property "CompanyName" r/w
	void PropertyBag::setCompanyName(LPCSTR szCompanyName);
	LPCSTR PropertyBag::getCompanyName();

	// Property "ApplicationName" r/w
	void PropertyBag::setApplicationName(LPCSTR szAppName);
	LPCSTR PropertyBag::getApplicationName();

	// Methods for adding/removing properties to/from the bag
	void add(LPCSTR szName, long *plData, long lDefault);
	void add(LPCSTR szName, int *pnData, int nDefault);
	void add(LPCSTR szName, short *pwData, short wDefault);
	void add(LPCSTR szName, char *pbData, char bDefault);
	void add(LPCSTR szName, LPCSTR szData, int nMaxLength, LPCSTR szDefault);
	void add(LPCSTR szSubItem, LPCSTR szName, long *plData, long lDefault);
	void add(LPCSTR szSubItem, LPCSTR szName, int *pnData, int nDefault);
	void add(LPCSTR szSubItem, LPCSTR szName, short *pwData, short wDefault);
	void add(LPCSTR szSubItem, LPCSTR szName, char *pbData, char bDefault);
	void add(LPCSTR szSubItem, LPCSTR szName, LPCSTR szData, int nMaxLength, LPCSTR szDefault);
	void clear();

	// Methods for storing/retreiving the properties to/from the registry
	bool exists();
	int store();
	int retrieve();
};
