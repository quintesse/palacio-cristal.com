
/****************************************************************************
** DeeEnEs - Automatic Dynamic IP Updater
** Copyright (C) 2000, 2001, 2002, 2003, 2004 Tako Schotanus
** 
** This program is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License
** as published by the Free Software Foundation; either version 2
** of the License, or (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
****************************************************************************/

#include <windows.h>
//#include <windowsx.h>
#include <string.h>
#include <ctype.h>
#include <winreg.h>
#include <string>
#include <list>
#include "PropertyBag.h"

using namespace std;

#define GAK_ERROR			0
#define GAK_NEW				1
#define GAK_EXISTING		2

PropertyBag::PropertyBag(LPCSTR szAppName) {
	setRoot(HKEY_CURRENT_USER);
	setCompanyName(NULL);
	setApplicationName(szAppName);
}

PropertyBag::PropertyBag(HKEY hRoot, LPCSTR szAppName) {
	setRoot(hRoot);
	setCompanyName(NULL);
	setApplicationName(szAppName);
}

PropertyBag::PropertyBag(LPCSTR szCompanyName, LPCSTR szAppName) {
	setRoot(HKEY_CURRENT_USER);
	setCompanyName(szCompanyName);
	setApplicationName(szAppName);
}

PropertyBag::PropertyBag(HKEY hRoot, LPCSTR szCompanyName, LPCSTR szAppName) {
	setRoot(hRoot);
	setCompanyName(szCompanyName);
	setApplicationName(szAppName);
}

PropertyBag::~PropertyBag() {
	setCompanyName(NULL);
	setApplicationName(NULL);
}

const string PropertyBag::getAppRegKeyStr(string sSubItem) {
	string s;

	s = "Software";
	if (!m_sCompanyName.empty()) {
		s = s + "\\" + m_sCompanyName;
	}
	if (!m_sAppName.empty()) {
		s = s + "\\" + m_sAppName;
	}
	if (!sSubItem.empty()) {
		s = s + "\\" + sSubItem;
	}

	return s;
}

UINT PropertyBag::findAppBaseKey(PHKEY lphKey, string sSubItem) {
	if (RegOpenKeyEx(m_hRoot, getAppRegKeyStr(sSubItem).c_str(), 0, KEY_READ, lphKey) == ERROR_SUCCESS) {
		return GAK_EXISTING;
	}
	return GAK_ERROR;
}

UINT PropertyBag::getAppBaseKey(PHKEY lphKey, string sSubItem) {
	DWORD dwDisp;

	if (RegCreateKeyEx(m_hRoot, getAppRegKeyStr(sSubItem).c_str(), 0, "", REG_OPTION_NON_VOLATILE, KEY_READ | KEY_WRITE, NULL, lphKey, &dwDisp) == ERROR_SUCCESS) {
		return (dwDisp == REG_OPENED_EXISTING_KEY) ? GAK_EXISTING : GAK_NEW;
	}
	return GAK_ERROR;
}

void PropertyBag::setRoot(HKEY hRoot) {
	m_hRoot = hRoot;
}

HKEY PropertyBag::getRoot() {
    return m_hRoot;
}

void PropertyBag::setCompanyName(LPCSTR szCompanyName) {
	if (szCompanyName) {
		m_sCompanyName = szCompanyName;
	} else {
		m_sCompanyName = "";
	}
}

LPCSTR PropertyBag::getCompanyName() {
    return m_sCompanyName.c_str();
}

void PropertyBag::setApplicationName(LPCSTR szAppName) {
	if (szAppName) {
		m_sAppName = szAppName;
	} else {
		m_sAppName = "";
	}
}

LPCSTR PropertyBag::getApplicationName() {
	return m_sAppName.c_str();
}

void PropertyBag::add(LPCSTR szName, long *plData, long lDefault) {
	add("", szName, plData, lDefault);
}

void PropertyBag::add(LPCSTR szName, int *pnData, int nDefault) {
	add("", szName, pnData, nDefault);
}

void PropertyBag::add(LPCSTR szName, short *pwData, short wDefault) {
	add("", szName, pwData, wDefault);
}

void PropertyBag::add(LPCSTR szName, char *pbData, char bDefault) {
	add("", szName, pbData, bDefault);
}

void PropertyBag::add(LPCSTR szName, LPCSTR szData, int nMaxLength, LPCSTR szDefault) {
	add("", szName, szData, nMaxLength, szDefault);
}

void PropertyBag::add(LPCSTR szSubItem, LPCSTR szName, long *plData, long lDefault) {
	struct PropertyInfo *pi;

	pi = new struct PropertyInfo;
	pi->sSubItem = szSubItem;
	pi->sName = szName;
	pi->nType = PT_NUMBER32;
	pi->Data.pl = plData;
	pi->Default.l = lDefault;
	m_bag.push_back(*pi);
}

void PropertyBag::add(LPCSTR szSubItem, LPCSTR szName, int *pnData, int nDefault) {
	struct PropertyInfo *pi;

	pi = new struct PropertyInfo;
	pi->sSubItem = szSubItem;
	pi->sName = szName;
	pi->nType = PT_NUMBER32;
	pi->Data.pl = (long *)pnData;
	pi->Default.l = (long)nDefault;
	m_bag.push_back(*pi);
}

void PropertyBag::add(LPCSTR szSubItem, LPCSTR szName, short *pwData, short wDefault) {
	struct PropertyInfo *pi;

	pi = new struct PropertyInfo;
	pi->sSubItem = szSubItem;
	pi->sName = szName;
	pi->nType = PT_NUMBER16;
	pi->Data.pw = pwData;
	pi->Default.w = wDefault;
	m_bag.push_back(*pi);
}

void PropertyBag::add(LPCSTR szSubItem, LPCSTR szName, char *pbData, char bDefault) {
	struct PropertyInfo *pi;

	pi = new struct PropertyInfo;
	pi->sSubItem = szSubItem;
	pi->sName = szName;
	pi->nType = PT_NUMBER8;
	pi->Data.pb = pbData;
	pi->Default.b = bDefault;
	m_bag.push_back(*pi);
}

void PropertyBag::add(LPCSTR szSubItem, LPCSTR szName, LPCSTR szData, int nMaxLength, LPCSTR szDefault) {
	struct PropertyInfo *pi;

	pi = new struct PropertyInfo;
	pi->sSubItem = szSubItem;
	pi->sName = szName;
	pi->nType = PT_STRING;
	pi->Data.s.text = szData;
	pi->Data.s.size = nMaxLength;
	pi->Default.s = strdup(szDefault);
	m_bag.push_back(*pi);
}

void PropertyBag::clear() {
	LISTPROP::iterator i;

	for (i =  m_bag.begin(); i != m_bag.end(); ++i) {
		if ((*i).nType == PT_STRING) {
			free((void *)(*i).Default.s);
		}
	}
	m_bag.clear();
}

bool PropertyBag::exists() {
	HKEY hKey;
	UINT uRes;

	uRes = findAppBaseKey(&hKey);
	if (uRes != GAK_ERROR) {
		RegCloseKey(hKey);
	}
	return (uRes != GAK_ERROR);
}

int PropertyBag::store() {
	LISTPROP::iterator i;
	const char *szName;
	int nRes = PB_OK;
	BYTE *pbVal;
	LONG lRes;
	HKEY hKey;

	for (i =  m_bag.begin();
	 i != m_bag.end();
	 ++i) {
		if (getAppBaseKey(&hKey, (*i).sSubItem) != GAK_ERROR) {
			szName = (*i).sName.c_str();
			switch ((*i).nType) {
				case PT_STRING:
					pbVal = (BYTE *)(*i).Data.s.text;
					if (!pbVal) {
						pbVal = (BYTE *)"";
					}
					lRes = RegSetValueEx(hKey, szName, 0, REG_SZ, pbVal, strlen((char *)pbVal)); 
					break;
				case PT_NUMBER32:
					pbVal = (BYTE *)((*i).Data.pl);
					lRes = RegSetValueEx(hKey, szName, 0, REG_DWORD, pbVal, sizeof(DWORD));
					break;
				case PT_NUMBER16:
					pbVal = (BYTE *)((*i).Data.pw);
					lRes = RegSetValueEx(hKey, szName, 0, REG_DWORD, pbVal, sizeof(DWORD));
					break;
				case PT_NUMBER8:
					pbVal = (BYTE *)((*i).Data.pb);
					lRes = RegSetValueEx(hKey, szName, 0, REG_DWORD, pbVal, sizeof(DWORD));
					break;
			}
			RegCloseKey(hKey);
			nRes = PB_OK;
		} else {
			nRes = PB_ERROR;
		}
	}

	return nRes;
}

int PropertyBag::retrieve() {
	LISTPROP::iterator i;
	DWORD dwType, dwVal, dwSize;
	bool bNewKey = FALSE;
	const char *szName;
	int nRes = PB_OK;
	BYTE *pbVal;
	LONG lRes;
	HKEY hKey;

	for (i =  m_bag.begin(); i != m_bag.end(); ++i) {
		if (getAppBaseKey(&hKey, (*i).sSubItem) != GAK_ERROR) {
			szName = (*i).sName.c_str();
			switch ((*i).nType) {
				case PT_STRING:
					dwSize = (*i).Data.s.size;
					pbVal = (BYTE *)(*i).Data.s.text;
					lRes = RegQueryValueEx(hKey, szName, NULL, &dwType, pbVal, &dwSize);
					if (lRes != ERROR_SUCCESS) {
						strncpy((char *)pbVal, (*i).Default.s, dwSize);
						((char *)pbVal)[dwSize - 1] = '\0';
						bNewKey = TRUE;
					}
					break;
				case PT_NUMBER32:
					dwSize = sizeof(DWORD);
					pbVal = (BYTE *)&dwVal;
					lRes = RegQueryValueEx(hKey, szName, NULL, &dwType, pbVal, &dwSize);
					if (lRes != ERROR_SUCCESS) {
						*((*i).Data.pl) = (*i).Default.l;
						bNewKey = TRUE;
					} else {
						*((*i).Data.pl) = (long)dwVal;
					}
					break;
				case PT_NUMBER16:
					dwSize = sizeof(DWORD);
					pbVal = (BYTE *)&dwVal;
					lRes = RegQueryValueEx(hKey, szName, NULL, &dwType, pbVal, &dwSize);
					if (lRes != ERROR_SUCCESS) {
						*((*i).Data.pw) = (*i).Default.w;
						bNewKey = TRUE;
					} else {
						*((*i).Data.pw) = (short)dwVal;
					}
					break;
				case PT_NUMBER8:
					dwSize = sizeof(DWORD);
					pbVal = (BYTE *)&dwVal;
					lRes = RegQueryValueEx(hKey, szName, NULL, &dwType, pbVal, &dwSize);
					if (lRes != ERROR_SUCCESS) {
						*((*i).Data.pb) = (*i).Default.b;
						bNewKey = TRUE;
					} else {
						*((*i).Data.pb) = (char)dwVal;
					}
					break;
			}
			RegCloseKey(hKey);
			if (bNewKey) nRes = PB_MISSING_KEYS;
		} else {
			nRes = PB_ERROR;
			break;
		}
	}

	return nRes;
}

