
/****************************************************************************
** DeeEnEs - Automatic Dynamic IP Updater
** Copyright (C) 2000, 2001, 2002, 2003, 2004 Tako Schotanus
** 
** This program is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License
** as published by the Free Software Foundation; either version 2
** of the License, or (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
****************************************************************************/


#include <windows.h>
#include <windowsx.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <winreg.h>
#include <ras.h>
#include "resource.h"
#include "PropertyBag.h"
#include "DeeEnEs.h"
#include "service.h"
#include "serverinfo.h"

//#define FAKE_UPDATE			1

#define IDI_ICON_TRAY_ON		IDI_ICON_DEEENES

#define SLEEP_SECOND			1000
#define SLEEP_MINUTE			(60 * SLEEP_SECOND)
#define SLEEP_HOUR				(60 * SLEEP_MINUTE)

#define DNS_NAME				LoadResString(IDS_DNS_NAME) // Altered by B.A.
#define DNS_SNAME				"DeeEnEs"
#define USER_AGENT				"User-Agent: DeeEnEs/2.3.30\r\n"
#define PROPERTY_TOKEN			"Peas Inc"

#define VERSION_HOST			"version.deeenes.palacio-cristal.com"
#define VERSION_REQUEST			"GET ###SERVER###/ HTTP/1.1\r\n"
#define VERSION_STR				"VERSION:"
#define REMARK_STR				"REMARK:"
#define ENDCOMMENT_STR			"-->"
#define	VERSION_TIME			(7 * 24 * SLEEP_HOUR)	// Check for new version every week
#define VERSION_MUTEX			TEXT("DeeEnEsVersionCheck")

#define STR_NO_ERROR			"NOERROR"
#define STR_INVALID_HOST		"Invalid Hostname"
#define STR_LOGON_FAILED		"401 Authorization Required"
#define STR_ABUSE				"Hostname blocked due to abuse"
#define STR_BAD_INPUT			"Bad Client Input"

#define MAX_ACCOUNTS			32

#define MAXLEN_HOST_NAME		80
#define MAXLEN_SERVER_NAME		80
#define MAXLEN_USER_NAME		32
#define MAXLEN_PASSWORD			32
#define MAXLEN_PROXY_SERVER		80
#define MAXLEN_PROXY_PORT		5
#define MAXLEN_PROXY_USER		32
#define MAXLEN_PROXY_PASSWORD	32
#define MAXLEN_MAILEXT			80
#define MAXLEN_OFFLINE_IP		15
#define MAXLEN_UPDATE_MSG		1024
#define MAXLEN_FIRST_CHECK		5
#define MAXLEN_DAYS_TO_UPDATE	2
#define MAXLEN_DATE				10	// We use the international format here: yyyy/mm/dd


enum UpdateMode {
	UPDATE_AUTO,
	UPDATE_MANUAL,
	UPDATE_FORCE,
	OFFLINE_MANUAL
};

#define CM_ERROR				-1
#define CM_FATAL_ERROR			-2
#define CM_WAIT					-3
#define CM_NO_ERROR				0

#define CONN_MODEM				0
#define CONN_LAN				1
#define CONN_WEB				2

#define DEF_AUTO_START			TRUE
#define DEF_START_DISABLED		FALSE
#define DEF_SHOW_TRAY_ICON		TRUE
#define DEF_DYNDNS_DONATOR		FALSE
#define DEF_SLEEP_TIME			(10 * SLEEP_MINUTE)	// 10 minutes
#define DEF_CONNECTION			CONN_WEB
#define DEF_INTERFACE			0
#define DEF_USE_PROXY			FALSE
#define DEF_PROXY_SERVER		""
#define DEF_PROXY_PORT			80
#define DEF_USE_BASIC_AUTH		FALSE
#define DEF_PROXY_NAME			""
#define DEF_PROXY_PASSWORD		""
#define DEF_VERSION_CHECK		TRUE
#define DEF_DETAILED_LOGGING	FALSE
#define DEF_FIRST_CHECK			1
#define DEF_DAYS_TO_UPDATE		28

#define DEF_UPDATE				TRUE
#define DEF_SERVER				0
#define DEF_SERVER_NAME			""
#define DEF_HOST_NAME			""
#define DEF_USER_NAME			""
#define DEF_PASSWORD			""
#define DEF_WILDCARDS			FALSE
#define DEF_MAILEXT				""
#define DEF_BACKUPMX			FALSE
#define DEF_OFFLINE_IP			"0.0.0.0"
#define DEF_LASTIP				0
#define DEF_LASTUPDATE			0
#define DEF_LAST_VERSION		""
#define DEF_LASTVERSIONCHECK	0

#define DEF_HELP_URL			"http://www.palacio-cristal.com/products/DeeEnEs/help.jsp"
#define DEF_DOWNLOAD_URL		"http://www.palacio-cristal.com/products/DeeEnEs/"

#define KEY_RUN					"Software\\Microsoft\\Windows\\CurrentVersion\\Run"

#define RASAPI_DLL				"RASAPI32.DLL"

#ifdef _DEBUG
	#define DbgMsg(x)			OutputDebugString(x)
#else
	#define DbgMsg(x)
#endif

#define GAK_ERROR				0
#define GAK_NEW					1
#define GAK_EXISTING			2

#define MYWM_NOTIFYICON			(WM_USER + 1)

#define TRAYMSG_ONOFF			1

#define TIMER_SLEEP				1
#define TIMER_ANIM				2
#define TIMER_VERSION			3

#define STATE_DISABLED			0
#define STATE_ENABLED			1
#define STATE_IDLE				2
#define STATE_CONNECTING		3
#define STATE_FLASHING			4

// Persistent variables (will be stored in the registry) - Can be found in the accounts dialog
struct AccountInfoType {
	char szHostName[MAXLEN_HOST_NAME+1];
	char szServer[MAXLEN_SERVER_NAME+1];	// New way of storing the account's server
	UINT uOldServer;						// Old way still here to be able to convert old to new format
	SERVINFO *aServer;						// Direct link to server info
	char szUserName[MAXLEN_USER_NAME+1];
	char szPassword[MAXLEN_PASSWORD+1];
	char szMailExt[MAXLEN_MAILEXT+1];
	BOOL bUpdate;
	BOOL bWildcards;
	BOOL bBackupMx;
	long lCurrIP;
	long lLastIP;
	time_t tmLastUpdate;
	char szLastUpdateMsg[MAXLEN_UPDATE_MSG+1];
	int nLastResult;
	UINT uSleep;
} AccountInfos[MAX_ACCOUNTS];

typedef struct AccountInfoType ACCINFO;

struct SleepTimeType {
	char *szText;
	UINT res;
	UINT nDelay;
} SleepTimes[] = {
//	"1",	IDS_SLEEP_MINUTE,	 5 * SLEEP_MINUTE,  // Needed some changes here for Language B.A....
	"10",	IDS_SLEEP_MINUTES,	10 * SLEEP_MINUTE,
	"15",	IDS_SLEEP_MINUTES,	15 * SLEEP_MINUTE,
	"20",	IDS_SLEEP_MINUTES,	20 * SLEEP_MINUTE,
	"25",	IDS_SLEEP_MINUTES,	25 * SLEEP_MINUTE,
	"30",	IDS_SLEEP_MINUTES,	30 * SLEEP_MINUTE,
	"45",	IDS_SLEEP_MINUTES,	45 * SLEEP_MINUTE,
	"1",	IDS_SLEEP_HOUR,		 1 * SLEEP_HOUR,
	"2",	IDS_SLEEP_HOURS,	 2 * SLEEP_HOUR,
	"3",	IDS_SLEEP_HOURS,	 3 * SLEEP_HOUR,
	"4",	IDS_SLEEP_HOURS,	 4 * SLEEP_HOUR,
	"8",	IDS_SLEEP_HOURS,	 8 * SLEEP_HOUR,
	"12",	IDS_SLEEP_HOURS,	12 * SLEEP_HOUR,
	"1",	IDS_SLEEP_DAY,		24 * SLEEP_HOUR,
	NULL, 0, 0
};

//---------------------------------------------------------------------------
// Function declarations
//---------------------------------------------------------------------------

void FillInterfaceList(HWND hDlg, int nDlgItem);
long GetIP(UINT uInterface);

int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hInstPrev, LPSTR lpstrCmdLine, int cmdShow);
int InitRAS(void);
void TermRAS(void);
void AddLogFileItem(const char *szText);
void SaveSettings();
void SetState(HWND hWnd, int nState, char *szToolTip);
void NotifyAdd(HWND hWnd);
void NotifyChange(HWND hWnd);
void NotifyDelete(HWND hWnd);
void DoShowAboutDlg(), DoShowPropDlg(), DoShowAccountsDlg(), DoShowLogDlg2(BOOL bShow);
int CALLBACK DeeEnEsWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
int CALLBACK LogDlgProc2(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
int CALLBACK PropertyDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
int CALLBACK AccountsDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
int CALLBACK AboutDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
int CALLBACK WizDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
void SelectAccount(ACCINFO *ai, HWND hDlg);
void UpdateAccount(ACCINFO *ai, HWND hDlg);
void SetAccountMsg(ACCINFO *ai, char *szMsg);
void InitBag(PropertyBag *b);
void CreateAccRegInfo(PropertyBag *b, bool bNew);
void InitFromRegistry();
char *GetDNSVersion();
void DoEnable();
void DoDisable();

//---------------------------------------------------------------------------
// Function prototype typedefs
//---------------------------------------------------------------------------

typedef DWORD (FAR PASCAL *PFNENUMCONNECTIONS)(LPRASCONN lprasconn, LPDWORD lpcb, LPDWORD lpcConnections);
typedef DWORD (FAR PASCAL *PFNGETCONNECTSTATUS)(HRASCONN hrasconn, LPRASCONNSTATUS lprasconnstatus);

//---------------------------------------------------------------------------
// Global Variables...
//---------------------------------------------------------------------------

HINSTANCE ghInstance;			// Global instance handle for application
HINSTANCE ghLangDepRes;			// Global instance for the language dependent resources
HWND ghDlgCurrent = NULL;		// Global handle to the currently active modeless dialog
HWND ghwndMain, ghLogDlg = 0, ghPropDlg = 0, ghAccDlg = 0, ghAboutDlg = 0, ghWizDlg;
HMODULE ghDLLInst = 0;
HANDLE ghVersionCheckMutex;
LPRASCONN glpRasConn = NULL;

PFNENUMCONNECTIONS EnumConnectionsP;
PFNGETCONNECTSTATUS GetConnectStatusP;

UINT guMenuTxt, guFlashIcon;
BOOL gbErrorOccurred = FALSE, gbAutoExit = FALSE, gbDetailedLogging = FALSE;
char *gszLastMessage = NULL, gszLogFile[MAX_PATH];
int gnAccountCount, gnState = STATE_IDLE;
long glCurrentIP;

PropertyBag bag(HKEY_LOCAL_MACHINE, PROPERTY_TOKEN, DNS_SNAME);
PropertyBag accbag(HKEY_LOCAL_MACHINE, PROPERTY_TOKEN, DNS_SNAME);

char gszTextBuf[MAXLEN_LANGOUTPUT];  // Rescource Text-Buffer

// Persistent variables (will be stored in the registry) - Can be found in the properties dialog
char gszLastVersion[16], gszOfflineIP[MAXLEN_OFFLINE_IP+1];
char gszProxyUser[MAXLEN_PROXY_USER+1], gszProxyPassword[MAXLEN_PROXY_PASSWORD+1];
char gszProxyServer[MAXLEN_PROXY_SERVER+1];
int gnProxyPortNr, gnFirstCheck, gnDaysToForcedUpdate;
UINT guSleepTime, guConnection, guInterface;
BOOL gbAutoStart, gbStartDisabled, gbDisabled, gbIsDynDNSDonator, gbShowIcon, gbUnload, gbUseProxy, gbUseBasicAuth;
BOOL gbVersionCheck;
time_t gtmLastVersionCheck;

//---------------------------------------------------------------------------
// WinMain
//---------------------------------------------------------------------------
int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hInstPrev, LPSTR lpstrCmdLine, int cmdShow)
{
	int retval = 0;
	//
	// Set the global instance variable
	//
	ghInstance = hInst;

	// Make sure the message buffer is initialized to prevent overruns
	gszTextBuf[sizeof(gszTextBuf) - 1] = '\0';

	// Try to load the language specific resource dll if it exists
	ghLangDepRes = LoadLibrary("DeeEnEs_lang.dll");
	if (!ghLangDepRes) {
		// otherwise use the (english) resources included in this program
		ghLangDepRes = hInst;
	}

/* Maybe use this in the future to be able to select the language in the options dialog
	HKEY hKey;
	ghLangDepRes = hInst;
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, "Software\\Peas Inc\\DeeEnEs", 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
		DWORD dwType, dwSize;
		char szLang[8];
		dwSize = sizeof(szLang);
		if ((RegQueryValueEx(hKey, "Language", NULL, &dwType, (LPBYTE)szLang, &dwSize)) == ERROR_SUCCESS) {
			char szFile[_MAX_PATH];
			GetModuleFileName(NULL, szFile, sizeof(szFile));
			char *p = strrchr(szFile, '.');
			strcpy(p, "_lang.dll");
			ghLangDepRes = LoadLibrary(szFile);
			if (!ghLangDepRes) {
				ghLangDepRes = hInst;
			}
		}
	}
*/


	_Module.Init( hInst, hInstPrev, IDS_SERVICENAME);
    TCHAR szTokens[] = _T("-/");

    LPCTSTR lpszToken = FindOneOf(lpstrCmdLine, szTokens);
    while (lpszToken != NULL)
    {
		if (lstrcmpi(lpszToken, _T("autoexit")) == 0) {
			gbAutoExit = TRUE;
		}
		if (lstrcmpi(lpszToken, _T("Uninstall")) == 0) {
			// Unregister as Service
			return _Module.Uninstall();
		}
        if (lstrcmpi(lpszToken, _T("Install")) == 0) {
			// Register as Service
			return _Module.Install(); //
		}
        lpszToken = FindOneOf(lpszToken, szTokens);
    }
	_Module.Start();

	StartRun(hInst, hInstPrev);

	return  0;
}



int StartRun(HINSTANCE hInst, HINSTANCE hInstPrev)
{
	MSG			msgMain;
	WNDCLASS	wc;
	//
	// Register the window class if this is the first instance.
	//
	if (hInstPrev == NULL)
	{
		wc.lpszMenuName			= NULL;
		wc.lpszClassName		= "DeeEnEsApp";
		wc.hInstance			= hInst;
		wc.hIcon	    		= LoadIcon(hInst, MAKEINTRESOURCE(IDI_ICON_DEEENES));
		wc.hCursor				= LoadCursor(NULL, IDC_ARROW);
		wc.hbrBackground		= (HBRUSH)(COLOR_WINDOW + 1);
		wc.style				= 0;
		wc.lpfnWndProc			= (WNDPROC)DeeEnEsWndProc;
		wc.cbClsExtra			= 0;
		wc.cbWndExtra			= 0;
		
		if (!RegisterClass(&wc)) {
			AddLogItem(ALI_DEBUG, GetString(IDS_LOG_REGWINCLASS));
			return(0);
		}
	}

	ghwndMain = FindWindow("DeeEnEsApp", "DeeEnEs");
	if (ghwndMain) {
		AddLogItem(ALI_DEBUG, GetString(IDS_LOG_PREVINSTANCE));
		PostMessage(ghwndMain, WM_COMMAND, IDM_VIEW_LOG, 0);
		return(0);
	}
	
	//
	// Create the main window
	//
	if ((ghwndMain = CreateWindow("DeeEnEsApp",
			"DeeEnEs",
			WS_OVERLAPPEDWINDOW,
			CW_USEDEFAULT, 0,
			100, 100,
			NULL, NULL, hInst, NULL)) == NULL) {
		AddLogItem(ALI_DEBUG, GetString(IDS_LOG_NOCREATEWIN));
		return(0);
	}

	if (!(ghVersionCheckMutex = CreateMutex(NULL, FALSE, VERSION_MUTEX))) {
		AddLogItem(ALI_DEBUG, GetString(IDS_LOG_NOMUTEX));
		return(0);
	}

	CoInitialize(NULL);
	
	if (GetModuleFileName(NULL, gszLogFile, MAX_PATH) > 0) {
		char *p = gszLogFile + strlen(gszLogFile) - 4;
		strcpy(p, ".log");
	}
	AddLogItem(ALI_DEBUG, GetString(IDS_LOG_INITPROG));
	
	InitRAS();
	InitFromRegistry();
	NotifyChange(ghwndMain);

	SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_LOWEST);

	_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_INITPROP), DNS_SNAME , GetDNSVersion());
	AddLogItem(ALI_INFO, gszTextBuf);

	//
	// Main message "pump"
	//
	while (GetMessage((LPMSG) &msgMain, NULL, 0, 0))
	{
		if (NULL == ghDlgCurrent || !IsDialogMessage(ghDlgCurrent, &msgMain)) {
			TranslateMessage((LPMSG) &msgMain);
			DispatchMessage((LPMSG) &msgMain);
		}
	}
	
	NotifyDelete(ghwndMain);
	KillTimer(ghwndMain, TIMER_SLEEP);
	KillTimer(ghwndMain, TIMER_ANIM);
	if (!gbAutoExit) KillTimer(ghwndMain, TIMER_VERSION);
	CloseHandle(ghVersionCheckMutex);

	SaveSettings();
	TermRAS();

	_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_TERMPROP), DNS_SNAME);
	AddLogItem(ALI_INFO, DNS_SNAME, gszTextBuf);

	CoUninitialize();

	return(0);
}


void TermRAS(void)
{
	if (glpRasConn) {
		GlobalFree((HGLOBAL)glpRasConn);
	}

	if (ghDLLInst) {
		if (FreeLibrary(ghDLLInst)) {
			ghDLLInst = 0;
		}
		AddLogItem(ALI_DEBUG, GetString(IDS_LOG_RASUNLOK));
	}
}

int InitRAS(void)
{
	AddLogItem(ALI_DETAIL + ALI_DEBUG, GetString(IDS_LOG_CHECKRAS));

	ghDLLInst = LoadLibrary(RASAPI_DLL);
	if (ghDLLInst) {
		AddLogItem(ALI_DEBUG, GetString(IDS_LOG_RASAPILOADOK));
		EnumConnectionsP = (PFNENUMCONNECTIONS)GetProcAddress(ghDLLInst, "RasEnumConnectionsA");
		GetConnectStatusP = (PFNGETCONNECTSTATUS)GetProcAddress(ghDLLInst, "RasGetConnectStatusA");
		if (!EnumConnectionsP || !GetConnectStatusP) {
			AddLogItem(ALI_DEBUG, GetString(IDS_LOG_NOPROCADDR));
			TermRAS();
			return -1;
		}
	} else {
		AddLogItem(ALI_DEBUG, GetString(IDS_LOG_NOLOADRAS));
		return -1;
	}

	glpRasConn = (LPRASCONN)GlobalAlloc(GPTR, sizeof(RASCONN));
	if (glpRasConn) {
		glpRasConn->dwSize = sizeof(RASCONN);
	}

	return 0;
}


int CheckRAS()
{
	DWORD dwCount, dwSize;
	int nRes;

	if (ghDLLInst) {
		dwSize = sizeof(RASCONN);
		dwCount = 1;
		if (EnumConnectionsP(glpRasConn, &dwSize, &dwCount) == 0) {
			if (dwCount > 0) {
				AddLogItem(ALI_DETAIL + ALI_DEBUG, GetString(IDS_LOG_NORASCONN));
				nRes = 1;
			} else {
				AddLogItem(ALI_DETAIL + ALI_DEBUG, GetString(IDS_LOG_NORASCONN2));
				nRes = 0;
			}
		} else {
			AddLogItem(ALI_DETAIL + ALI_DEBUG, GetString(IDS_LOG_NOENUMRAS));
			nRes = -1; // Don't know, something went wrong!
		}
	} else {
		AddLogItem(ALI_DETAIL + ALI_DEBUG, GetString(IDS_LOG_NORASMAYBELAN));
		nRes = -1;	// Don't know, we could have a LAN connection to te Internet!
	}

	return nRes;
}


void SetAnimationTimer(BOOL bOn)
{
	UINT uRes;

	if (bOn) {
		uRes = SetTimer(ghwndMain, TIMER_ANIM, 500, NULL);
	} else {
		KillTimer(ghwndMain, TIMER_ANIM);
	}
}


char *GetString(UINT nStringID)
{	static char szText[MAXLEN_LANGOUTPUT];

	if (!LoadString(ghLangDepRes, nStringID, szText, sizeof(szText))) {
		if (!LoadString(ghInstance, nStringID, szText, sizeof(szText))) {
			*szText = '\0';
		}
	}

	return szText;
}


char *Val(long lNr)
{	static char szBuf[33];

	return ltoa(lNr, szBuf, 10);
}


// The following code is borrowed from the sample code at http://www.sockets.com
/*-----------------------------------------------------------
 * Function: GetAddr()
 *
 * Description: Given a string, it will return an IP address.
 *   - first it tries to convert the string directly
 *   - if that fails, it tries o resolve it as a hostname
 *
 * WARNING: gethostbyname() is a blocking function
 */
DWORD GetAddr (const char *szHost) 
{
	LPHOSTENT lpstHost;
	u_long lAddr = INADDR_ANY;
	_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_GETADDRFOR), szHost);
	AddLogItem(ALI_DEBUG, gszTextBuf);

	/* check that we have a string */
	if (*szHost) {
		/* check for a dotted-IP address string */
		lAddr = inet_addr(szHost);
		/* If not an address, then try to resolve it as a hostname */
		if ((lAddr == INADDR_NONE) && (strcmp(szHost, "255.255.255.255"))) {
			lpstHost = gethostbyname(szHost);
			if (lpstHost) {  /* success */
				_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_HOSTRESOLVED), szHost);
				AddLogItem(ALI_DEBUG, gszTextBuf);
				lAddr = *((u_long FAR *) (lpstHost->h_addr));
			} else {
				_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_NOHOSTWINSOCK), szHost, Val(WSAGetLastError()));
				AddLogItem(ALI_DEBUG, gszTextBuf);
				lAddr = INADDR_ANY;   /* failure */
			}
		} else {
			_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_ISIPNOLOOKUP), szHost);
			AddLogItem(ALI_DEBUG, gszTextBuf);
		}
	}

	return (lAddr); 
}


char *StrReplace(char *szText, char *szFind, char *szReplace)
{
	char szBuf[1024], *p, *q, *r;

	p = szText;
	q = szBuf;
	r = strstr(p, szFind);
	while (*p) {
		if (p == r) {
			strncpy(q, szReplace, strlen(szReplace));
			p += strlen(szFind);
			q += strlen(szReplace);
			r = strstr(p, szFind);
		} else {
			*q++ = *p++;
		}
	}
	*q = '\0';

	strcpy(szText, szBuf);

	return szText;
}


char *EncodeBase64String(char *szText)
{
	static char szBuf[1536];
	char *p, szEnc[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	int nBuffdBits = 0, nBuf = 0, nEnc = 0, nTriple;

	p = szBuf;
	while (*szText || (nBuffdBits > 0)) {
		if (*szText && (nBuffdBits < 6)) {
			nBuf |= ((*szText++) << (8 - nBuffdBits));
			nBuffdBits += 8;
		}
		nEnc = (nBuf & 0xfc00) >> 10;
		nBuf = (nBuf <<= 6) & 0xfc00;
		*p++ = szEnc[nEnc];
		nBuffdBits -= 6;
	}
	nTriple = strlen(szText);
	while (nTriple && nTriple < 3) {
		nTriple ++;
		*p++ = '=';
	}
	*p = '\0';

	return szBuf;
}


char *BoolStrOnOff(BOOL bVal)
{
	return (bVal) ? "ON" : "OFF";
}


char *BoolStrYesNo(BOOL bVal)
{
	return (bVal) ? "YES" : "NO";
}


char *MakeSimpleHttpGetRequest(char *szHost, char *szRequest, char *szBuf)
{
	char szServ[MAXLEN_HOST_NAME+8];

	*szBuf = '\0';
	strcat(szBuf, szRequest);
	strcat(szBuf, "Host: ");
	strcat(szBuf, szHost);
	strcat(szBuf, "\r\n");
	strcat(szBuf, "Content-Type: application/x-www-form-urlencoded\r\n");
	strcat(szBuf, "Cache-Control: no-cache\r\n");
	strcat(szBuf, USER_AGENT);
	strcat(szBuf, "\r\n");

	if (gbUseProxy) {
		strcpy(szServ, "http://");
		strcat(szServ, szHost);
	} else {
		szServ[0] = '\0';
	}

	StrReplace(szBuf, "###SERVER###", szServ);

	return szBuf;
}


char *MakeHttpGetRequest(ACCINFO *ai, enum UpdateMode nMode, char *szBuf)
{
	char szAuth[MAXLEN_USER_NAME + MAXLEN_PASSWORD + 2], szServ[MAXLEN_HOST_NAME+8], szHost[2*MAXLEN_HOST_NAME+1];

	*szBuf = '\0';
	bool bCanUseOffline = (ai->aServer->aService->szOfflineRequest != NULL);
	bool bMayUseOffline = (gbIsDynDNSDonator || ((ai->aServer->aService->lFlags && SCETF_OFFLINE_DONATORS_ONLY) == 0));
	if ((nMode != OFFLINE_MANUAL) || !bCanUseOffline || !bMayUseOffline) {
		strcat(szBuf, ai->aServer->aService->szRequest);
	} else {
		strcat(szBuf, ai->aServer->aService->szOfflineRequest);
	}
	strcat(szBuf, "Host: ");
	strcat(szBuf, ai->aServer->aService->szHost);
	strcat(szBuf, "\r\n");
	strcat(szBuf, "Authorization: Basic ###CREDENTIALS###\r\n");
	strcat(szBuf, "Content-Type: application/x-www-form-urlencoded\r\n");
	strcat(szBuf, "Cache-Control: no-cache\r\n");
	strcat(szBuf, USER_AGENT);
	strcat(szBuf, "\r\n");

	strcpy(szAuth, ai->szUserName);
	strcat(szAuth, ":");
	strcat(szAuth, ai->szPassword);

	if (gbUseProxy) {
		strcpy(szServ, "http://");
		strcat(szServ, ai->aServer->aService->szHost);
	} else {
		szServ[0] = '\0';
	}

	strcpy(szHost, ai->szHostName);
	if ((ai->aServer->nFlags & SRVTF_CUSTOM_DOMAIN) == 0) {
		strcat(szHost, ".");
		strcat(szHost, ai->aServer->szName);
	}

	StrReplace(szBuf, "###SERVER###", szServ);
	StrReplace(szBuf, "###HOST###", szHost);
	if (nMode != OFFLINE_MANUAL) {
		StrReplace(szBuf, "###IP###", inet_ntoa(*((IN_ADDR *)&ai->lCurrIP)));
	} else {
		StrReplace(szBuf, "###IP###", gszOfflineIP);
	}
	StrReplace(szBuf, "###WILDCARD###", BoolStrOnOff(ai->bWildcards));
	StrReplace(szBuf, "###MAILEXT###", ai->szMailExt);
	StrReplace(szBuf, "###BACKUPMX###", BoolStrYesNo(ai->bBackupMx));
	StrReplace(szBuf, "###CREDENTIALS###", EncodeBase64String(szAuth));

	return szBuf;
}

SOCKET InitHttpRequest()
{
	SOCKET cSck = INVALID_SOCKET;
	WSADATA WSAData;

	if (WSAStartup(MAKEWORD(1, 1), &WSAData) == 0) {
		AddLogItem(ALI_DEBUG, GetString(IDS_LOG_WINSOKINITOK));
		if ((cSck = socket(PF_INET,SOCK_STREAM,0)) != INVALID_SOCKET) {
			AddLogItem(ALI_DEBUG, GetString(IDS_LOG_WINSCKCREATED));
		} else {
			_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_WINSCKNOCREATE), Val(WSAGetLastError()));
			AddLogItem(ALI_DEBUG, gszTextBuf);
		}
	} else {
		_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_WINSCKNOINIT), Val(WSAGetLastError()));
		AddLogItem(ALI_DEBUG, gszTextBuf);
	}
	return cSck;
}


BOOL SendHttpRequest(SOCKET cSck, char *szHost, int nPortNr, char *szRequest)
{
	SOCKADDR_IN sin;
	BOOL bRes = FALSE;
	int nBytes;
	AddLogItem(ALI_DEBUG, GetString(IDS_LOG_WINSCKTRYCONN));
	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;

	if (gbUseProxy) {
		sin.sin_port = htons(gnProxyPortNr);
		sin.sin_addr.s_addr = GetAddr(gszProxyServer);
	} else {
		sin.sin_port = htons(nPortNr);
		sin.sin_addr.s_addr = GetAddr(szHost);
	}

	if ((sin.sin_addr.s_addr != INADDR_ANY) && (sin.sin_addr.s_addr != INADDR_NONE)) {
		AddLogItem(ALI_DEBUG, GetString(IDS_LOG_REMOKCONN));
		int nlen = sizeof(sockaddr);
		if (connect(cSck, (struct sockaddr *)&sin, nlen) == 0) {
			AddLogItem(ALI_DETAIL + ALI_DEBUG, GetString(IDS_LOG_CONNOKSNDUPD));
			_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_REQTOSERVER), szRequest);
			AddLogItem(ALI_DEBUG, gszTextBuf);
			if ((nBytes = send(cSck, szRequest, strlen(szRequest), 0)) > 0) {
				AddLogItem(ALI_DETAIL + ALI_DEBUG, GetString(IDS_LOG_SENDNOWWAIT));
				bRes = TRUE;
			} else {
				_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_REQFAILED), Val(WSAGetLastError()) );
				AddLogItem(ALI_ERROR + ALI_DEBUG, gszTextBuf);
			}
		} else {
			_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_REQFAILNOCONN), Val(WSAGetLastError()) );
			AddLogItem(ALI_ERROR + ALI_DEBUG, gszTextBuf);
		}
	} else {
		AddLogItem(ALI_ERROR + ALI_DEBUG, GetString(IDS_LOG_REQFAILWRONGADDR));
	}

	return bRes;
}


int ReadHttpData(SOCKET cSck, char *szBuf, int nSize)
{
	int nBytes, nTotalBytes = 0;

	memset(szBuf, 0, nSize);
	while (((nBytes = recv(cSck, szBuf + nTotalBytes, nSize - nTotalBytes - 1, 0)) > 0) && (nBytes != SOCKET_ERROR)) {
		nTotalBytes += nBytes;
		szBuf[nTotalBytes] = '\0';
	}
	_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_DATAFROMSERVER), szBuf );
	AddLogItem(ALI_DEBUG, gszTextBuf);
	return nTotalBytes;
}


void CleanupHttpRequest(SOCKET cSck)
{
	if (cSck != INVALID_SOCKET) {
		closesocket(cSck);
		AddLogItem(ALI_DEBUG, GetString(IDS_LOG_SOCKETCLOSED));
	}
	WSACleanup();
	AddLogItem(ALI_DEBUG, GetString(IDS_LOG_WINSCKCLEANED));
}


int GetHTTPResult(char *szBuf)
{
	int nRes;

	if (strnicmp(szBuf, "HTTP/", 5) == 0) {
		szBuf = strchr(szBuf + 5, ' ') + 1;
		nRes = atoi(szBuf);
	} else {
		nRes = 0;
	}

	return nRes;
}


int DaysDiff(time_t tmLastUpdate)
{	time_t tmNow;

	time(&tmNow);

	int nDays = ((tmNow - tmLastUpdate) / (24 * 60 * 60));

	return nDays;
}


long GetValidIP(char **szText)
{
	char *p, *s;
	int n;
	
	p = s = *szText;

	// An IP address can never be shorter than 7 characters
	n = strspn(p, "1234567890.");
	if (n < 7) {
		*szText = p + n;
		return 0;
	}

	// It should consist of 4 groups
	for (int i = 0; i < 4; i++) {
		// Each group should be a number of at least 1 and at most 3 digits
		n = strspn(p, "1234567890");
		if ((n < 1) || (n > 3)) {
			*szText = p + n;
			return 0;
		}
		p += n;
		// And separated by a period
		if (i == 3) {
			if (*p == '.') {
				*szText = p + 1;
				return 0;
			} else {
				*p = '\0';
			}
		}
		p++;
	}

	*szText = p;

	return inet_addr(s);
}


long GetWebIP(UINT uInterface)
{
	char szBuf[1025], *p;
	int nBytes;
	long lIP = 0;

	WebIPDetectorType *webip = &WebIPDetectors[uInterface];
	SOCKET cSck = InitHttpRequest();
	if (SendHttpRequest(cSck, webip->szHost, webip->nPortNr, MakeSimpleHttpGetRequest(webip->szHost, webip->szRequest, szBuf))) {
		int i = 0;
		while ((i < 2) && (lIP == 0) && (nBytes = recv (cSck, szBuf, sizeof(szBuf) - 1, 0)) > 0) {
			szBuf[nBytes] = '\0';
			_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_GETWEBIPREC), szBuf );
			AddLogItem(ALI_DEBUG, gszTextBuf);
			if (i == 0) {
				// The header and contents might be in one packet or it might be chunked into seperate ones.
				// If this is the first packet we receive it will be the HTTP header so we find the end of the headers
				// (we do this because it is possible that in the HTTP headers there will be some IP numbers as well)
				// to see if the IP can be found after it. If not we'll wait and try the second packet.
				_strlwr(szBuf);
				if ((p = strstr(szBuf, "\r\n\r\n")) == NULL) {
					p = szBuf;
				}
			} else {
				p = szBuf;
			}
			// We'll now look for the first occurrance of something that looks like a valid IP address
			while (*p && !lIP) {
				int n = strcspn(p, "1234567890");
				p += n;
				lIP = GetValidIP(&p);
			}
			i++;
		}
	}
	CleanupHttpRequest(cSck);

	return lIP;
}


long GetIPEx(UINT uInterface) {
	if (guConnection == CONN_WEB) {
		return GetWebIP(uInterface);
	} else {
		return GetIP(uInterface);
	}
}


int HandleOldProtocol(ACCINFO *ai, char *szBuf)
{
	char *szMsg;
	int nRes;

	if (strstr(szBuf, STR_NO_ERROR) != NULL) {
		_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_UPDATEGOOD), ai->szHostName, ai->aServer->szName);
		AddLogItem(ALI_INFO, gszTextBuf);
		ai->lLastIP = ai->lCurrIP;
		time(&ai->tmLastUpdate);
		nRes = CM_NO_ERROR;
	} else {
		ai->bUpdate = FALSE;	// Deactivate the account so we don't keep trying to update misconfigured accounts
		if (strstr(szBuf, STR_LOGON_FAILED) != NULL) {
			szMsg = GetString(IDS_LOG_BADAUTH);
			AddLogItem(ALI_ERROR, szMsg);
			SetAccountMsg(ai, szMsg);
		} else {
			if (strstr(szBuf, STR_INVALID_HOST) != NULL) {
				szMsg = GetString(IDS_LOG_INVALIDHOST);
				AddLogItem(ALI_ERROR, szMsg);
				SetAccountMsg(ai, szMsg);
			} else {
				if (strstr(szBuf, STR_ABUSE) != NULL) {
					szMsg = GetString(IDS_LOG_ACCTABUSE);
					AddLogItem(ALI_ERROR, szMsg);
					SetAccountMsg(ai, szMsg);
				} else {
					if (strstr(szBuf, STR_BAD_INPUT) != NULL) {
						szMsg = GetString(IDS_LOG_BADINPUT);
						AddLogItem(ALI_ERROR, szMsg);
						SetAccountMsg(ai, szMsg);
					} else {
						ai->bUpdate = TRUE;	// It could be something temporary so let's keep the account activated...
						szMsg = GetString(IDS_LOG_ERRUNKNOWN);
						AddLogItem(ALI_ERROR, szMsg);
						SetAccountMsg(ai, szMsg);
					}
				}
			}
		}
		nRes = CM_ERROR;
	}

	return nRes;
}


char *DeChunk(char *szBuf) {

	char *p = szBuf;
	while (*p) {
		// Find end of line and terminate it
		char *q = strstr(p, "\r\n");
		if (q == NULL) break;
		*q = '\0';
		// The first line should contain a hexadecimal number teling us the length of the chunk
		unsigned long lLength = strtoul(p, NULL, 16);
		// Move the chunk's data
		memmove(p, q + 2, strlen(q + 2) + 1);
		// Skip the chunk's data
		p += lLength;
		if (strstr(p, "\r\n") == p) {
			p += 2;
		}
	}

	return szBuf;
}


int HandleNewProtocol(ACCINFO *ai, char *szBuf) {
	char *p, *szHTTPHeaders, *szHTTPBody, *szMsg;
	int nRes;

	szHTTPHeaders = szBuf;
	p = strstr(szBuf, "\r\n\r\n");
	if (p) {
		*p = '\0';
		p += 4;
		szHTTPBody = p;

		if (strstr(szHTTPHeaders, "Transfer-Encoding: chunked") != NULL) {
			// Transfer is chunked, let's de-chunck our data
			DeChunk(szHTTPBody);
		}

		// Let's find the end of the first line in the result because that's all we're interested in
		char *q = strstr(p, "\r\n");
		if (q) {
			*q = '\0';
		}

		_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_RETURNCODE), p);
		AddLogItem(ALI_DETAIL, gszTextBuf);

		if (!strnicmp(p, "good ", 5)) {
			// Update was performed okay
			szMsg = GetString(IDS_LOG_NDUPDATESUCCESS);
			_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, szMsg, ai->szHostName, ai->aServer->szName);
			AddLogItem(ALI_INFO, gszTextBuf);
			SetAccountMsg(ai, gszTextBuf);
			ai->lLastIP = ai->lCurrIP;
			time(&ai->tmLastUpdate);
			nRes = CM_NO_ERROR;
		} else if (!strncmp(p, "nochg ", 6)) {
			// We've just made an abusive update, let's tell the user
			szMsg = GetString(IDS_LOG_NSNOCHG);
			AddLogItem(ALI_ERROR, szMsg);
			SetAccountMsg(ai, szMsg);
			ai->lLastIP = ai->lCurrIP;
			time(&ai->tmLastUpdate);
			char szTxt[1024];
			if (LoadString(ghLangDepRes, IDS_ABUSIVE_UPDATE, szTxt, sizeof(szTxt))) {
				MessageBox(NULL, szTxt, GetString(IDS_LOG_NSNOCHGHEAD), MB_OK + MB_ICONWARNING);
			}
			nRes = CM_NO_ERROR;
		} else if (!strcmp(p, "!donator")) {
			// User wants something he/she hasn't paid for
			szMsg = GetString(IDS_LOG_NDNODONATOR);
			AddLogItem(ALI_ERROR, szMsg);
			SetAccountMsg(ai, szMsg);
			gbIsDynDNSDonator = FALSE;	// Turn off DynDNS-specific offline setting
			if (ghPropDlg) {
				CheckDlgButton(ghPropDlg, IDC_CHECK_DONATOR, BST_UNCHECKED);
			}
		} else if (*p == 'w') {
			p++;
			char *expl = strstr(p, " ");
			if (expl) {
				*expl++ = '\0';
			}
			UINT waittime;
			char *last = p + strlen(p) - 1;
			char waittype = *last;
			*last = '\0';
			switch (waittype) {
				case 'h':
					waittime = 3600 * 1000;
					break;
				case 'm':
					waittime = 60 * 1000;
					break;
				case 's':
					waittime = 1000;
					break;
			}
			int factor = atoi(p);
			waittime *= factor;
			ai->uSleep = waittime;
			nRes = CM_WAIT;
		} else {
			if (!strcmp(p, "notfqdn")) {
				szMsg = GetString(IDS_LOG_DNNOTFQDN);
				AddLogItem(ALI_ERROR, szMsg);
				SetAccountMsg(ai, szMsg);
			} else if (!strcmp(p, "nohost")) {
				szMsg = GetString(IDS_LOG_NDNOHOST);
				AddLogItem(ALI_ERROR, szMsg);
				SetAccountMsg(ai, szMsg);
			} else if (!strcmp(p, "!yours")) {
				szMsg = GetString(IDS_LOG_NOTYOURS);
				AddLogItem(ALI_ERROR, szMsg);
				SetAccountMsg(ai, szMsg);
			} else if (!strcmp(p, "!active")) {
				szMsg = GetString(IDS_LOG_NOTACTIVE);
				AddLogItem(ALI_ERROR, szMsg);
				SetAccountMsg(ai, szMsg);
			} else if (!strcmp(p, "abuse")) {
				szMsg = GetString(IDS_LOG_NDABUSE);
				AddLogItem(ALI_ERROR, szMsg);
				SetAccountMsg(ai, szMsg);
			} else if (!strncmp(p, "numhost ", 8) || !strncmp(p, "dnserr ", 7)) {
				_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_NDNUMHOST), p);
				AddLogItem(ALI_ERROR, gszTextBuf);
				SetAccountMsg(ai, GetString(IDS_LOG_NDNUMHOST2));
			} else if (!strcmp(p, "911") || !strcmp(p, "999")) {
				szMsg = GetString(IDS_LOG_ND911999);
				AddLogItem(ALI_ERROR, szMsg);
				GetString(IDS_LOG_ND9119992);
				SetAccountMsg(ai, szMsg);
			} else if (!strcmp(p, "badauth")) {
				szMsg = GetString(IDS_LOG_NDBADAUTH);
				AddLogItem(ALI_ERROR, szMsg);
				SetAccountMsg(ai, szMsg);
			} else if (!strcmp(p, "badsys")) {
				szMsg = GetString(IDS_LOG_NDBADSYS);
				AddLogItem(ALI_ERROR, szMsg);
				SetAccountMsg(ai, szMsg);
			} else if (!strcmp(p, "badagent")) {
				szMsg = GetString(IDS_LOG_NDBADAGENT);
				AddLogItem(ALI_ERROR, szMsg);
				SetAccountMsg(ai, szMsg);
			} else {
				_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_NDUNKNOWN), p);
				AddLogItem(ALI_ERROR, gszTextBuf);
				SetAccountMsg(ai, GetString(IDS_LOG_NDUNKNOWN2));
			}
			ai->bUpdate = FALSE;	// Deactivate the account so we don't keep trying to update misconfigured accounts
			if (ghAccDlg) {
				CheckDlgButton(ghAccDlg, IDC_CHECK_UPDATE, BST_UNCHECKED);
			}
			nRes = CM_ERROR;
		}
	} else {
		szMsg = GetString(IDS_LOG_NDUNKNOWNALL);
		AddLogItem(ALI_ERROR, szMsg);
		SetAccountMsg(ai, szMsg);
		nRes = CM_FATAL_ERROR;
	}

	return nRes;
}

UINT MinSleepTime()
{
	if (guConnection == CONN_WEB) {
		return guSleepTime;			// We don't want too much traffic when doing Web IP checks
	} else {
		return 30 * 1000;			// We can check a lot more often when not doing Web IP checks
	}
}


void UpdateIP(enum UpdateMode nMode) {
	if (nMode != OFFLINE_MANUAL) {
		glCurrentIP = GetIPEx(guInterface);
		if (!glCurrentIP) {
			AddLogItem(ALI_ERROR + ALI_DEBUG, GetString(IDS_LOG_NOINTERFACE));
			if (!gbErrorOccurred) {
				SetState(ghwndMain, STATE_DISABLED, GetString(IDS_STATE_NOCONNECT));
				SetAnimationTimer(false);
			}
			return;
		}
		_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_CURRIP), inet_ntoa(*((IN_ADDR *)&glCurrentIP)));
		AddLogItem(ALI_DEBUG, gszTextBuf);
	} else {
		glCurrentIP = inet_addr(gszOfflineIP);
		if (glCurrentIP == INADDR_NONE) {
			glCurrentIP = 0;
		}
	}
	if (ghLogDlg) {
		SetDlgItemText(ghLogDlg, IDC_EDIT_SHOWIP, inet_ntoa(*((IN_ADDR *)&glCurrentIP)));
	}
}


void UpdateDNS(ACCINFO *ai, enum UpdateMode nMode)
{
	struct tm *tmNow;
	int nRes = CM_ERROR;
	char szBuf[1024+1], *szMsg;
	int nBytes;
	long lAddr;

	if (!ai->bUpdate || (ai->uSleep > 0)) {
		return;
	}

	lAddr = glCurrentIP;
	if (nMode != OFFLINE_MANUAL) {
		if (!lAddr) {
			SetAccountMsg(ai, GetString(IDS_LOG_NOINTERFACE2));
			ai->nLastResult = CM_NO_ERROR;
			return;
		}
		_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_CURRIP), inet_ntoa(*((IN_ADDR *)&lAddr)));
		AddLogItem(ALI_DEBUG, gszTextBuf);
	}

	// Check if an update is necessary, this happens for one of 3 reasons:
	// - the IP is different
	// - the last update has been longer than the max time set in the options
	// - the update has been forced by the user
	ai->lCurrIP = lAddr;
	if ((nMode != UPDATE_FORCE) && (ai->lCurrIP == ai->lLastIP) && (DaysDiff(ai->tmLastUpdate) < gnDaysToForcedUpdate)) {
		// No update necessary
		_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_NOIPCHNG), ai->szHostName, ai->aServer->szName);
		AddLogItem((nMode == UPDATE_MANUAL) ? ALI_INFO : ALI_DETAIL + ALI_DEBUG, gszTextBuf);
		tmNow = localtime(&ai->tmLastUpdate);
		strftime(szBuf, sizeof(szBuf), GetString(IDS_LOG_STILLUPTODATE), tmNow);
		SetAccountMsg(ai, szBuf);
		if (!gbErrorOccurred) {
			SetState(ghwndMain, STATE_IDLE, GetString(IDS_LOG_UPDSUCCESS));
			SetAnimationTimer(false);
		}
		ai->nLastResult = CM_NO_ERROR;
		return;
	}

	_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_UPDATOI), ai->szHostName, ai->aServer->szName, inet_ntoa(*((IN_ADDR *)&ai->lCurrIP)));
	AddLogItem(ALI_INFO, gszTextBuf);
	SetAccountMsg(ai, GetString(IDS_LOG_UPDATING));

	SetAnimationTimer(FALSE);
	SetState(ghwndMain, STATE_CONNECTING, NULL);

	SOCKET cSck = InitHttpRequest();
	if (SendHttpRequest(cSck, ai->aServer->aService->szHost, ai->aServer->aService->nPortNr, MakeHttpGetRequest(ai, nMode, szBuf))) {
		nBytes = ReadHttpData(cSck, szBuf, 1024);
		if (nBytes != SOCKET_ERROR) {
			int nCode = GetHTTPResult(szBuf);
			if (nCode == 200) {
				switch (ai->aServer->aService->nProtocol) {
					case PROT_DYNDNS_OLD:
						nRes = HandleOldProtocol(ai, szBuf);
						break;
					case PROT_DYNDNS_NEW:
						nRes = HandleNewProtocol(ai, szBuf);
						break;
				}
				if (nRes == CM_NO_ERROR) {
					ai->uSleep = MinSleepTime();
				}
			} else if (nCode == 401) {
				ai->bUpdate = FALSE;
				szMsg = GetString(IDS_LOG_WRONGUSERPW);
				AddLogItem(ALI_ERROR, szMsg);
				SetAccountMsg(ai, szMsg);
				nRes = CM_ERROR;
			} else {
				SetAccountMsg(ai, GetString(IDS_LOG_FAILCOMPROB));
				ai->uSleep = 15 * 60 * 1000;		// We got an HTTP error, let's wait at least 15 minutes before trying again
				nRes = CM_FATAL_ERROR;
			}
		} else {
			_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_COULDNOTREC), Val(WSAGetLastError()));
			AddLogItem(ALI_ERROR + ALI_DEBUG, gszTextBuf);
			SetAccountMsg(ai, GetString(IDS_LOG_COULDNOTREC2));
			ai->uSleep = 60 * 1000;		// We got an WinSock error, let's wait at least 1 minute before trying again
			nRes = CM_ERROR;
		}
	}
	ai->nLastResult = nRes;
	CleanupHttpRequest(cSck);
}

DWORD WINAPI UpdateAllDNSThread(LPVOID lpParameter)
{
	enum UpdateMode nMode = ((enum UpdateMode)(int)lpParameter);
	int nRes;
	AddLogItem(ALI_DETAIL, GetString(IDS_LOG_CHECKING));

	if (gszLastMessage) {
		free(gszLastMessage);
        gszLastMessage = NULL;
	}

	if (guConnection == CONN_MODEM) {
		nRes = CheckRAS();
		if (nRes == -1) {
			nRes = 1; // Let's just try and see what happens...
		}
	} else {
		nRes = 1;
	}

	if (nRes == 1) {
		UpdateIP(nMode);
		nRes = (glCurrentIP != 0) ? 1 : 0;
	}

	UINT uSleep = MinSleepTime();
	if (nRes == 1) {
		if (gbAutoExit) {
			gbErrorOccurred = FALSE;
		}

		// Update all accounts
		int i;
		int nActive = 0;
		nRes = CM_NO_ERROR;
		for (i=0; i<gnAccountCount; i++) {
			ACCINFO *ai = &AccountInfos[i];
			if (ai->bUpdate && (ai->uSleep == 0)) {
				nActive++;
#ifndef FAKE_UPDATE
				UpdateDNS(ai, nMode);
				if (ai->nLastResult != CM_NO_ERROR) {
					nRes = ai->nLastResult;
				}
#endif
			}
		}

		// Save the account states to the registry
		SaveSettings();	// So we will remember the last IP

		// Quit the program if auto-exit was enabled and no errors have occurred
		if (!gbErrorOccurred && gbAutoExit) {
			PostMessage(ghwndMain, WM_QUIT, 0, 0);
		}

		// Determine the time until the next update (the account with the shortest wait time)
		// But make sure that time is never sorter than MinSleepTime which is at least
		// 5 seconds (for Modem/Lan) or guSleepTime mseconds (for Web-Based)
		uSleep = 0;
		for (i=0; i<gnAccountCount; i++) {
			ACCINFO *ai = &AccountInfos[i];
			if (ai->bUpdate) {
				if ((uSleep == 0) || (ai->uSleep < uSleep)) {
					uSleep = ai->uSleep;
					if (uSleep < MinSleepTime()) {
						uSleep = MinSleepTime();
					}
				}
				nActive--;
			}
		}

		// Set tray icon and tooltip
		if (!gbErrorOccurred) {
			// Current state is normal. Check for errors
			if ((nRes != CM_NO_ERROR) || (nActive != 0)) {
				SetState(ghwndMain, STATE_FLASHING, GetString(IDS_STATE_UPDFAIL));
				AddLogItem(ALI_DETAIL, GetString(IDS_LOG_UPDFAIL));
				gbErrorOccurred = TRUE;
			} else {
				char szMsg[200];
				_snprintf(szMsg, sizeof(szMsg) - 1, "%s (%s)", GetString(IDS_STATE_UPDOK), inet_ntoa(*((IN_ADDR *)&glCurrentIP)));
				SetState(ghwndMain, STATE_IDLE, szMsg);
				AddLogItem(ALI_DETAIL, GetString(IDS_LOG_UPDOK));
			}
			SetAnimationTimer(nRes != CM_NO_ERROR);
		} else {
			SetState(ghwndMain, STATE_FLASHING, GetString(IDS_STATE_UPDFAIL));
			SetAnimationTimer(TRUE);
		}

		// Substract the time until the next check from the time an account still
		// has to wait before it may check for updates. If it reaches 0 it will
		// check if it should update the next time this function is called.
		for (i=0; i<gnAccountCount; i++) {
			ACCINFO *ai = &AccountInfos[i];
			if (ai->bUpdate) {
				if (uSleep < ai->uSleep) {
					ai->uSleep -= uSleep;
				} else {
					ai->uSleep = 0;
				}
			}
		}
	} else if (nRes == 0) {
		if (!gbErrorOccurred) {
			SetState(ghwndMain, STATE_DISABLED, GetString(IDS_STATE_NOCONNECTION));
			SetAnimationTimer(false);
		}
	}

	// Set the amount of time this thread should go to sleep
	if (uSleep) {
		SetTimer(ghwndMain, TIMER_SLEEP, uSleep, NULL);
	}

	return 0;
}


void UpdateAllDNS(enum UpdateMode nMode)
{
	DWORD dwThreadId;
	HANDLE hThrd = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)UpdateAllDNSThread, (LPVOID)nMode, 0, &dwThreadId);
	SetThreadPriority(hThrd, THREAD_PRIORITY_LOWEST);
	CloseHandle(hThrd);
}


// Compares 2 version strings v1 and v2 and returns:
//	-1 if v1 < v2
//	 0 if v1 = v2
//	 1 if v1 > v2
int VersionCmp(char *szVersion1, char *szVersion2)
{
	char szVerBuf1[16], szVerBuf2[16];
	char *szVer1, *szVer2, *p1, *p2;
	int n1, n2;

	szVer1 = szVerBuf1;
	szVer2 = szVerBuf2;
	strcpy(szVer1, szVersion1);
	strcpy(szVer2, szVersion2);
	p1 = strchr(szVer1, '.');
	p2 = strchr(szVer2, '.');
	while (szVer1 && *szVer1 && szVer2 && *szVer2) {
		if (p1) *p1 = '\0';
		if (p2) *p2 = '\0';
		n1 = atoi(szVer1);
		n2 = atoi(szVer2);
		if (n1 > n2) return 1;
		if (n2 > n1) return -1;
		if (p1) {
			szVer1 = p1 + 1;
			p1 = strchr(szVer1, '.');
		} else {
			szVer1 = NULL;
		}
		if (p2) {
			szVer2 = p2 + 1;
			p2 = strchr(szVer2, '.');
		} else {
			szVer2 = NULL;
		}
	}

	if (szVer1 && *szVer1) return 1;
	if (szVer2 && *szVer2) return -1;

	return 0;
}


UINT versionWait() {
	time_t tmNow;

	time(&tmNow);

	long secs = (VERSION_TIME / SLEEP_SECOND) - (tmNow - gtmLastVersionCheck);

	if (secs < (gnFirstCheck + 1)) {
		secs = gnFirstCheck + 1;
	}

	return (UINT)secs * SLEEP_SECOND;
}


DWORD WINAPI CheckVersionThread(LPVOID lpParameter)
{
	enum UpdateMode nMode = ((enum UpdateMode)(int)lpParameter);
	DWORD nRes = CM_ERROR;
	char szBuf[1025], szMsg[1537], *pVersion, *pRemark, *pEndRemark;
	int nBytes;

	if (WaitForSingleObject(ghVersionCheckMutex, 0) != WAIT_OBJECT_0) {
		return nRes;
	}

	__try {
		AddLogItem(ALI_INFO, GetString(IDS_LOG_CHECKNEWVER));

		SOCKET cSck = InitHttpRequest();
		if (SendHttpRequest(cSck, VERSION_HOST, 80, MakeSimpleHttpGetRequest(VERSION_HOST, VERSION_REQUEST, szBuf))) {
			if ((nBytes = recv(cSck, szBuf, sizeof(szBuf) - 1, 0)) > 0)
			{
				szBuf[nBytes] = '\0';
				_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_VERFROMSERV), szBuf);
				AddLogItem(ALI_DEBUG, gszTextBuf);
				pVersion = strstr(szBuf, VERSION_STR);
				pRemark = strstr(szBuf, REMARK_STR);
				if (pRemark != NULL) {
					pEndRemark = strstr(pRemark, ENDCOMMENT_STR);
					if (pEndRemark != NULL) {
						pRemark += sizeof(REMARK_STR) - 1;
						*pEndRemark = '\0';
					} else {
						pRemark = pEndRemark = NULL;
					}
				}
				if ((pRemark != NULL) && (strcmp(pRemark, "DISABLE") == 0)) {
					DoDisable();
					AddLogItem(ALI_INFO, GetString(IDS_MSG_DISABLED_BY_SERVER));
					MessageBox(NULL, GetString(IDS_MSG_DISABLED_BY_SERVER), GetString(IDS_DNS_DISABLED), MB_OK + MB_ICONEXCLAMATION);
					ShellExecute(ghwndMain, "open", DEF_DOWNLOAD_URL, NULL, NULL, SW_SHOWNORMAL);
				} else {
					if (pVersion != NULL) {
						AddLogItem(ALI_DEBUG, GetString(IDS_LOG_VERNEW));
						pVersion += sizeof(VERSION_STR) - 1;
						*strchr(pVersion, ' ') = '\0';
						if (VersionCmp(GetDNSVersion(), pVersion) < 0) {
							_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_VERNEW2), pVersion);
							AddLogItem(ALI_INFO, gszTextBuf);
							if ((nMode == UPDATE_MANUAL) || (VersionCmp(gszLastVersion, pVersion) < 0)) {
								sprintf( szMsg, GetString(IDS_MSG_NEWVER), pVersion, GetDNSVersion());
								if (pRemark != NULL) {
									strcat(szMsg, GetString(IDS_MSG_NEWVERREM));
									strcat(szMsg, pRemark);
								}
								strcat(szMsg, GetString(IDS_MSG_NEWVERDL));
								if (MessageBox(NULL, szMsg, GetString(IDS_MSG_NEWVERWINTITLE), MB_YESNO + MB_ICONQUESTION) == IDYES) {
									ShellExecute(ghwndMain, "open", DEF_DOWNLOAD_URL, NULL, NULL, SW_SHOWNORMAL);
								}
								strcpy(gszLastVersion, pVersion);
							}
						} else {
							AddLogItem(ALI_INFO, GetString(IDS_LOG_PRGUP2DATE));
						}
						nRes = CM_NO_ERROR;
					} else {
						AddLogItem(ALI_ERROR, GetString(IDS_LOG_NOVERINFO));
					}
				}
			}
		}
		CleanupHttpRequest(cSck);
	}
	__finally {
		ReleaseMutex(ghVersionCheckMutex);
	}

	// Make sure we don't check again for some time
	time(&gtmLastVersionCheck);

	if (gbVersionCheck) {
		SetTimer(ghwndMain, TIMER_VERSION, versionWait(), NULL);
	}

	return nRes;
}


void CheckVersion(enum UpdateMode nMode)
{
	DWORD dwThreadId;

	if (gbVersionCheck) {
		HANDLE hThrd = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckVersionThread, (LPVOID)nMode, 0, &dwThreadId);
		SetThreadPriority(hThrd, THREAD_PRIORITY_LOWEST);
		CloseHandle(hThrd);
	}
}


BOOL TrayMessage(HWND hWnd, DWORD dwMessage, UINT uID, HICON hIcon, PSTR pszTip)
{
	NOTIFYICONDATA tnd;
	BOOL res;

	tnd.cbSize				= sizeof(NOTIFYICONDATA);
	tnd.hWnd				= hWnd;
	tnd.uID					= uID;
	tnd.uFlags				= NIF_MESSAGE|NIF_ICON|NIF_TIP;
	tnd.uCallbackMessage	= MYWM_NOTIFYICON;
	tnd.hIcon				= hIcon;

	if (pszTip)
		lstrcpyn(tnd.szTip, pszTip, sizeof(tnd.szTip));
	else
		tnd.szTip[0] = '\0';

	res = Shell_NotifyIcon(dwMessage, &tnd);

	if (hIcon)
	    DestroyIcon(hIcon);

	return res;
}


void SetState(HWND hWnd, int nState, char *szToolTip)
{
	LPCSTR pszIDIcon;
	UINT uTip, uIcon;
	HICON hIcon;
	char *pszTip;

	gnState = nState;
	if (nState == STATE_IDLE) {
		nState = (gbDisabled) ? STATE_DISABLED : STATE_ENABLED;
	}

	switch (nState) {
		case STATE_DISABLED:
			uTip = IDS_DNS_DISABLED;
			uIcon = IDI_ICON_TRAY_OFF;
			guMenuTxt = IDS_ENABLE;
			gnState = STATE_IDLE;
			break;
		case STATE_ENABLED:
            if (gszLastMessage) {
                uTip = 0;
                pszTip = gszLastMessage;
            } else {
				uTip = IDS_DNS_ENABLED;
            }
			uIcon = IDI_ICON_TRAY_ON;
			guMenuTxt = IDS_DISABLE;
			gnState = STATE_IDLE;
			break;
		case STATE_CONNECTING:
			uTip = IDS_DNS_CONNECTING;
			uIcon = IDI_ICON_TRAY_CONNECTING;
			guMenuTxt = ((gbDisabled) ? IDS_ENABLE : IDS_DISABLE);
			break;
		case STATE_FLASHING:
            if (gbErrorOccurred && gszLastMessage) {
                uTip = 0;
                pszTip = gszLastMessage;
            } else {
			    uTip = IDS_DNS_NEWS;
            }
			uIcon = guFlashIcon;
			guMenuTxt = ((gbDisabled) ? IDS_ENABLE : IDS_DISABLE);
	}

	if (szToolTip) {
		pszTip = szToolTip;
	} else {
		if (uTip != 0) {
			pszTip = GetString(uTip);
		}
	}

	pszIDIcon = MAKEINTRESOURCE(uIcon);
	hIcon = (HICON)LoadImage(ghInstance, pszIDIcon, IMAGE_ICON, 16, 16, 0);
	if (!hIcon)
		return;

	TrayMessage(hWnd, NIM_MODIFY, TRAYMSG_ONOFF, hIcon, pszTip);
}


void StateChange(HWND hWnd, INT nSelect)
{
	BOOL bActive;
	int nState;

	if (nSelect < 0) {
		bActive = gbDisabled;
	} else {
		bActive = (nSelect == 1);
		gbDisabled = bActive;
	}
	if (bActive) {
		nState = STATE_DISABLED;
	} else {
		if (gbErrorOccurred) {
			nState = STATE_FLASHING;
		} else {
			nState = STATE_ENABLED;
		}
	}

	SetState(hWnd, nState, NULL);
}


void NotifyDelete(HWND hWnd)
{
	TrayMessage(hWnd, NIM_DELETE, TRAYMSG_ONOFF, NULL, NULL);
}


void NotifyAdd(HWND hWnd)
{
	TrayMessage(hWnd, NIM_ADD, TRAYMSG_ONOFF, NULL, NULL);

	StateChange(hWnd, -1);
}


void NotifyChange(HWND hWnd)
{
	if (gbShowIcon) {
		NotifyAdd(hWnd);
	} else {
		NotifyDelete(hWnd);
	}
}


LRESULT IconDrawItem(LPDRAWITEMSTRUCT lpdi)
{
	HICON hIcon;

	hIcon = (HICON)LoadImage(ghInstance, MAKEINTRESOURCE(lpdi->CtlID), IMAGE_ICON, 16, 16, 0);
	if (!hIcon)
		return(FALSE);

	DrawIconEx(lpdi->hDC, lpdi->rcItem.left, lpdi->rcItem.top, hIcon, 16, 16, 0, NULL, DI_NORMAL);

	return(TRUE);
}


void SetDefaultMenuItem(HMENU hMenu, UINT uItemId)
{
	MENUITEMINFO mii;

	mii.cbSize = sizeof(MENUITEMINFO);
	mii.fMask = MIIM_STATE;
	mii.fState = MFS_DEFAULT;
	SetMenuItemInfo(hMenu, uItemId, FALSE, &mii); 
}


void SetMenuItemEnable(HMENU hMenu, UINT uItemId, BOOL bEnabled)
{
	MENUITEMINFO mii;

	mii.cbSize = sizeof(MENUITEMINFO);
	mii.fMask = MIIM_STATE;
	mii.fState = (bEnabled) ? MFS_ENABLED : MFS_DISABLED;
	SetMenuItemInfo(hMenu, uItemId, FALSE, &mii); 
}


void SetMenuItemText(HMENU hMenu, UINT uItemId, LPSTR szTxt)
{
	MENUITEMINFO mii;

	mii.cbSize = sizeof(MENUITEMINFO);
	mii.fMask = MIIM_TYPE;
	mii.fType = MFT_STRING;
	mii.dwTypeData = szTxt;
	mii.cch = strlen(szTxt);
	SetMenuItemInfo(hMenu, uItemId, FALSE, &mii); 
}


void HandleMenu(HWND hDlg)
{
	UINT uID, uFlags;
	POINT cpos;
	HMENU hMenu;

	hMenu = (HMENU)LoadMenu(ghLangDepRes, MAKEINTRESOURCE(IDM_TRAY));
	if (hMenu) {
		SetDefaultMenuItem(hMenu, IDM_VIEW_LOG);

		SetMenuItemEnable(hMenu, IDM_SNOOZE, gbErrorOccurred);

		SetMenuItemText(hMenu, IDM_DISABLE, GetString(guMenuTxt));

		GetCursorPos(&cpos);
		SetForegroundWindow(hDlg);

		uFlags = TPM_VERTICAL | TPM_RIGHTALIGN | TPM_VCENTERALIGN;
		uID = TrackPopupMenuEx(GetSubMenu(hMenu, 0), uFlags, cpos.x, cpos.y, hDlg, NULL);

		DestroyMenu(hMenu);
	}
}


int DoShowWizDlg(UINT nDialog)
{
	int nRes = IDCANCEL;

//	if (!gbWizDlgShown) {
		nRes = DialogBoxParam(ghLangDepRes, MAKEINTRESOURCE(nDialog), NULL, WizDlgProc, nDialog);
//	}

	return nRes;
}


BOOL DoIntroduction()
{
	int nRes;

//	if (InitDLL() == 0) {
//		FreeDLL();
//		guConnection = CONN_MODEM;
//	} else {
//		guConnection = CONN_LAN;
//	}

page_welcome:
	nRes = DoShowWizDlg(IDD_DIALOG_WELCOME);
	if (nRes == IDCANCEL) {
		return FALSE;
	}

page_connection:
	nRes = DoShowWizDlg(IDD_DIALOG_CONNECTION);
	if (nRes == IDCANCEL) {
		return FALSE;
	}
	if (nRes == IDC_BUTTON_BACK) {
		goto page_welcome;
	}

page_user:
	nRes = DoShowWizDlg(IDD_DIALOG_USER);
	if (nRes == IDCANCEL) {
		return FALSE;
	}
	if (nRes == IDC_BUTTON_BACK) {
		goto page_connection;
	}

//page_final:
	nRes = DoShowWizDlg(IDD_DIALOG_FINAL_OK);
	if (nRes == IDCANCEL) {
		return FALSE;
	}
	if (nRes == IDC_BUTTON_BACK) {
		goto page_user;
	}

	return TRUE;
}


char *GetDNSVersion()
{	static char szVersion[16];

	// Using ghInstance here because we don't want the translated version
	LoadString(ghInstance, IDS_VERSION, szVersion, sizeof(szVersion));

	return szVersion;
}


void SetRunKey(BOOL bEnable)
{
	HKEY hKey;
	long lRes;
	DWORD dwDisp;

	if (_Module.m_bService) {
		// No matter what the value of bEnable, if we run as a service we will remove ourself from the Windows auto start sequence
		bEnable = FALSE;
	}

	char sProg[MAX_PATH];
	if (GetModuleFileName(NULL, sProg, MAX_PATH) > 0) {
		if (RegCreateKeyEx(HKEY_CURRENT_USER, KEY_RUN, 0, "", REG_OPTION_NON_VOLATILE, KEY_READ | KEY_WRITE, NULL, &hKey, &dwDisp) == ERROR_SUCCESS) {
			if (bEnable) {
				lRes = RegSetValueEx(hKey, DNS_SNAME, 0, REG_SZ, (BYTE *)sProg, strlen(sProg)); 
				AddLogItem(ALI_DEBUG, GetString(IDS_LOG_AUTOREGENABLE));
			} else {
				lRes = RegDeleteValue(hKey, DNS_SNAME); 
				AddLogItem(ALI_DEBUG, GetString(IDS_LOG_AUTOREGDISABLE));
			}
			RegCloseKey(hKey);
		} else {
			AddLogItem(ALI_ERROR + ALI_DEBUG, GetString(IDS_LOG_AUTOREGSETFAIL));
		}
	} else {
		AddLogItem(ALI_ERROR + ALI_DEBUG, GetString(IDS_LOG_AUTOREGMODERR));
	}
}


BOOL LoadSettings()
{
	BOOL bNewKeysAdded = FALSE;

	// Test if old property settings were found and if new ones already exist
	PropertyBag test(PROPERTY_TOKEN, DNS_SNAME);
	if (test.exists() && !bag.exists()) {
		// New ones don't exist yet, import old ones
		AddLogItem(ALI_DEBUG, GetString(IDS_LOG_PREFRET));
		InitBag(&test);
		bNewKeysAdded = (test.retrieve() == PB_MISSING_KEYS);
	} else {
		// Old ones don't exist or new ones already created. Retrieve them.
		AddLogItem(ALI_DEBUG, GetString(IDS_LOG_PREFRET2));
		bNewKeysAdded = (bag.retrieve() == PB_MISSING_KEYS);
	}
	if (bNewKeysAdded) {
		AddLogItem(ALI_DEBUG, GetString(IDS_LOG_PREFDETECTED));
	}

	// Test if old accounts were found and if new ones already exist
	PropertyBag acctest(PROPERTY_TOKEN, DNS_SNAME);
	CreateAccRegInfo(&accbag, true);
	if (acctest.exists() && !accbag.exists()) {
		// New ones don't exist yet, import old ones
		AddLogItem(ALI_DEBUG, GetString(IDS_LOG_PREFRET3));
		CreateAccRegInfo(&acctest, false);
		acctest.retrieve();
		if (gnAccountCount > MAX_ACCOUNTS) {
			// Invalid data in registry
			gnAccountCount = MAX_ACCOUNTS;
		}
		// The old system used indices into a table to determine which server to use for an account
		// We now store server names so to convert the old account info to the new we look up the
		// server names in the old table using the index and store its name for the new system
		for (int i=0; i<gnAccountCount; i++) {
			ACCINFO *ai = &AccountInfos[i];
			if (ai->uOldServer < SIZE_OLDSERVERNAMES) {
				strcpy(ai->szServer, szOldDNSServerNames[ai->uOldServer]);
			} else {
				// array boundary crossed
				*ai->szServer = '\0';
			}
		}
	} else {
		AddLogItem(ALI_DEBUG, GetString(IDS_LOG_ACCTRET));
//		CreateAccRegInfo(&accbag, true);
		accbag.retrieve();
	}

	if (gnAccountCount > MAX_ACCOUNTS) {
		// Invalid data in registry
		gnAccountCount = MAX_ACCOUNTS;
	}
	// Find and store reference to server info
	for (int i=0; i<gnAccountCount; i++) {
		ACCINFO *ai = &AccountInfos[i];
		ai->aServer = NULL;
		SERVINFO *si = DNSServers;
		while ((ai->aServer == NULL) && (si->szName != NULL)) {
			if (!strcmp(ai->szServer, si->szName)) {
				// Found the selected server, remember it
				ai->aServer = si;
				break;
			}
			si++;
		}
		if (ai->aServer == NULL) {
			// We didn't find the server so we disable the account
			ai->bUpdate = false;
		}
		ai->uSleep = 0;
	}
	AddLogItem(ALI_DEBUG, GetString(IDS_LOG_RETRIEVED));


	if (guInterface >= SIZE_WEBIPDETECTORS) {
		// Invalid data in the registry or using older, unsupported IP detectors, switching to DynDNS
		guInterface = 0;
	}

	if (guSleepTime < 5000) {
		// Less than 5 seconds between checks is not allowed
		guSleepTime = 5000;
	}

	return bNewKeysAdded;
}


void SaveSettings()
{
	AddLogItem(ALI_DEBUG, GetString(IDS_LOG_PREFSTOR));
	bag.store();

	AddLogItem(ALI_DEBUG, GetString(IDS_LOG_ACCTSTOR));
	accbag.store();

	SetRunKey(gbAutoStart);

	AddLogItem(ALI_DEBUG, GetString(IDS_LOG_STORED));
}


void CreateAccRegInfo(PropertyBag *b, bool bNew)
{
	// The following settings can be found in the accounts dialog
	b->clear();
	AddLogItem(ALI_DEBUG, GetString(IDS_LOG_CREATEREGINFOACC));
	for (int i=0; i<gnAccountCount; i++) {
		char szKey[16];
		strcpy(szKey, "Accounts\\");
		itoa(i, szKey + strlen(szKey), 10);
		_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(IDS_LOG_CREATEREGINFOACCT2), szKey);
		AddLogItem(ALI_DEBUG, gszTextBuf);
		ACCINFO *ai = &AccountInfos[i];
		b->add(szKey, "Update", &ai->bUpdate, DEF_UPDATE);
		if (bNew) {
			b->add(szKey, "Server", ai->szServer, sizeof(ai->szServer), DEF_SERVER_NAME);
		} else {
			b->add(szKey, "Server", (signed *)&ai->uOldServer, DEF_SERVER);
		}
		b->add(szKey, "HostName", ai->szHostName, sizeof(ai->szHostName), DEF_HOST_NAME);
		b->add(szKey, "UserName", ai->szUserName, sizeof(ai->szUserName), DEF_USER_NAME);
		b->add(szKey, "Password", ai->szPassword, sizeof(ai->szPassword), DEF_PASSWORD);
		b->add(szKey, "Wildcards", &ai->bWildcards, DEF_WILDCARDS);
		b->add(szKey, "MailExtender", ai->szMailExt, sizeof(ai->szMailExt), DEF_MAILEXT);
		b->add(szKey, "BackupMX", &ai->bBackupMx, DEF_BACKUPMX);
		b->add(szKey, "LastIP", &ai->lLastIP, DEF_LASTIP);
		b->add(szKey, "LastUpdate", &ai->tmLastUpdate, DEF_LASTUPDATE);
	}

}


void InitBag(PropertyBag *b)
{
	// The following settings can be found in the properties dialog
	b->add("AutoStart", &gbAutoStart, DEF_AUTO_START);
	b->add("StartDisabled", &gbStartDisabled, DEF_START_DISABLED);
	b->add("ShowTrayIcon", &gbShowIcon, DEF_SHOW_TRAY_ICON);
	b->add("IsDynDNSDonator", &gbIsDynDNSDonator, DEF_DYNDNS_DONATOR);
	b->add("SleepTime", (signed *)&guSleepTime, DEF_SLEEP_TIME);
	b->add("UseProxy", &gbUseProxy, DEF_USE_PROXY);
	b->add("Connection", (signed *)&guConnection, DEF_CONNECTION);
	b->add("Interface", (signed *)&guInterface, DEF_INTERFACE);
	b->add("OfflineIP", gszOfflineIP, sizeof(gszOfflineIP), DEF_OFFLINE_IP);
	b->add("ProxyServer", gszProxyServer, sizeof(gszProxyServer), DEF_PROXY_SERVER);
	b->add("ProxyPort", &gnProxyPortNr, DEF_PROXY_PORT);
	b->add("UseBasicAuthentication", &gbUseBasicAuth, DEF_USE_BASIC_AUTH);
	b->add("ProxyUser", gszProxyUser, sizeof(gszProxyUser), DEF_PROXY_NAME);
	b->add("ProxyPassword", gszProxyPassword, sizeof(gszProxyPassword), DEF_PROXY_PASSWORD);
	b->add("VersionCheck", &gbVersionCheck, DEF_VERSION_CHECK);
//	b->add("DetailedLogging", &gbDetailedLogging, DEF_DETAILED_LOGGING);//BA enabled. Why not ?
	b->add("FirstCheck", &gnFirstCheck, DEF_FIRST_CHECK);
	b->add("DaysToForcedUpdate", &gnDaysToForcedUpdate, DEF_DAYS_TO_UPDATE);

	b->add("Accounts", "Count", &gnAccountCount, 0);
	b->add("LastVersion", gszLastVersion, sizeof(gszLastVersion), DEF_LAST_VERSION);
	b->add("LastVersionCheck", &gtmLastVersionCheck, DEF_LASTVERSIONCHECK);
}


void InitFromRegistry()
{
	AddLogItem(ALI_DEBUG, GetString(IDS_LOG_CREATEREGINFOPREF));

	InitBag(&bag);
	gbDisabled = gbStartDisabled;

	BOOL bNew = LoadSettings();
	if (bNew) {
		DoShowPropDlg();				//TODO: Make these dialogs blocking!! (but only here!)
		if (!gnAccountCount) {
			DoShowAccountsDlg();
		}
		SaveSettings();
//		if (DoIntroduction()) {
//			SaveSettings();
//		} else {
//			PostQuitMessage(0);
//		}
	} else {
		SetRunKey(gbAutoStart);
	}

	if (gnAccountCount && !gbDisabled) {
		SetTimer(ghwndMain, TIMER_SLEEP, gnFirstCheck * 1000, NULL);	// The first check will be done after gnFirstCheck seconds
	}
	if (gbVersionCheck && !gbDisabled && !gbAutoExit) {
		SetTimer(ghwndMain, TIMER_VERSION, versionWait(), NULL);	// The first check will be done 1 second after the account check
	}
}


void PropDlgUpdateButtonStates(HWND hDlg)
{
	HWND hWnd;

	hWnd = GetDlgItem(hDlg, IDC_EDIT_PROXY_SERVER);
	EnableWindow(hWnd, (BOOL)IsDlgButtonChecked(hDlg, IDC_CHECK_USE_PROXY));
	hWnd = GetDlgItem(hDlg, IDC_EDIT_PROXY_PORT);
	EnableWindow(hWnd, (BOOL)IsDlgButtonChecked(hDlg, IDC_CHECK_USE_PROXY));

//	hWnd = GetDlgItem(hDlg, IDC_EDIT_PROXY_USER);
//	EnableWindow(hWnd, (BOOL)IsDlgButtonChecked(hDlg, IDC_CHECK_USE_AUTHENTICATION));
//	hWnd = GetDlgItem(hDlg, IDC_EDIT_PROXY_PASSWORD);
//	EnableWindow(hWnd, (BOOL)IsDlgButtonChecked(hDlg, IDC_CHECK_USE_AUTHENTICATION));
}


void FillInterfaceWebList(HWND hDlg, int nDlgItem)
{
	HWND hWnd;

	if (guConnection == CONN_WEB) {
		SendDlgItemMessage(hDlg, nDlgItem, CB_RESETCONTENT, 0, 0);
		WebIPDetectorType *webip = WebIPDetectors;
		while (webip->szName) {
			SendDlgItemMessage(hDlg, nDlgItem, CB_ADDSTRING, 0, (DWORD)((LPSTR)webip->szName));
			webip++;
		}
	} else {
		// FillInterfaceList(hDlg, nDlgItem);
		FillInterfaceList(hDlg, nDlgItem);
	}

	hWnd = GetDlgItem(hDlg, IDC_COMBO_SLEEP);
	EnableWindow(hWnd, (guConnection == CONN_WEB));
}


void PropDlgSetButtonStates(HWND hDlg)
{
	struct SleepTimeType *stt;
	int nIdx, nSelected;

	CheckDlgButton(hDlg, IDC_CHECK_AUTO_START, ((gbAutoStart) ? BST_CHECKED : BST_UNCHECKED));

	CheckDlgButton(hDlg, IDC_CHECK_START_DISABLED, ((gbStartDisabled) ? BST_CHECKED : BST_UNCHECKED));

	SetDlgItemInt(hDlg, IDC_EDIT_FIRST_CHECK, gnFirstCheck, FALSE);
	SendDlgItemMessage(hDlg, IDC_EDIT_FIRST_CHECK, EM_SETLIMITTEXT, MAXLEN_FIRST_CHECK, 0);

	SetDlgItemInt(hDlg, IDC_EDIT_FORCE_UPDATE_AFTER, gnDaysToForcedUpdate, FALSE);
	SendDlgItemMessage(hDlg, IDC_EDIT_FORCE_UPDATE_AFTER, EM_SETLIMITTEXT, MAXLEN_DAYS_TO_UPDATE, 0);

	nIdx = nSelected = 0;
	stt = SleepTimes;
	while (stt->szText) {
		if (stt->nDelay <= guSleepTime) {
			nSelected = nIdx;
		}
		nIdx++;
		stt++;
	}
	SendDlgItemMessage(hDlg, IDC_COMBO_SLEEP, CB_SETCURSEL, nSelected, 0);

	SendDlgItemMessage(hDlg, IDC_COMBO_CONNECTION, CB_SETCURSEL, guConnection, 0);

	FillInterfaceWebList(hDlg, IDC_COMBO_INTERFACE);

	SendDlgItemMessage(hDlg, IDC_COMBO_INTERFACE, CB_SETCURSEL, guInterface, 0);

	SetDlgItemText(hDlg, IDC_EDIT_OFFLINE_IP, gszOfflineIP);
	SendDlgItemMessage(hDlg, IDC_EDIT_OFFLINE_IP, EM_SETLIMITTEXT, MAXLEN_OFFLINE_IP, 0);

	CheckDlgButton(hDlg, IDC_CHECK_DONATOR, ((gbIsDynDNSDonator) ? BST_CHECKED : BST_UNCHECKED));

	CheckDlgButton(hDlg, IDC_CHECK_USE_PROXY, ((gbUseProxy) ? BST_CHECKED : BST_UNCHECKED));

	SetDlgItemText(hDlg, IDC_EDIT_PROXY_SERVER, gszProxyServer);
	SendDlgItemMessage(hDlg, IDC_EDIT_PROXY_SERVER, EM_SETLIMITTEXT, MAXLEN_PROXY_SERVER, 0);

	SetDlgItemInt(hDlg, IDC_EDIT_PROXY_PORT, gnProxyPortNr, FALSE);
	SendDlgItemMessage(hDlg, IDC_EDIT_PROXY_PORT, EM_SETLIMITTEXT, MAXLEN_PROXY_PORT, 0);

//	CheckDlgButton(hDlg, IDC_CHECK_USE_AUTHENTICATION, ((gbUseBasicAuth) ? BST_CHECKED : BST_UNCHECKED));

//	SetDlgItemText(hDlg, IDC_EDIT_PROXY_USER, gszProxyUser);
//	SendDlgItemMessage(hDlg, IDC_EDIT_PROXY_USER, EM_SETLIMITTEXT, MAXLEN_PROXY_USER, 0);

//	SetDlgItemText(hDlg, IDC_EDIT_PROXY_PASSWORD, gszProxyPassword);
//	SendDlgItemMessage(hDlg, IDC_EDIT_PROXY_PASSWORD, EM_SETLIMITTEXT, MAXLEN_PROXY_PASSWORD, 0);

	CheckDlgButton(hDlg, IDC_CHECK_VERSION_CHECK, ((gbVersionCheck) ? BST_CHECKED : BST_UNCHECKED));

	CheckDlgButton(hDlg, IDC_CHECK_DETAILED_LOGGING, ((gbDetailedLogging) ? BST_CHECKED : BST_UNCHECKED));

	PropDlgUpdateButtonStates(hDlg);
}


void PropDlgGetButtonStates(HWND hDlg)
{
	UINT uIface;
	int nIdx;

	gbAutoStart = (BOOL)IsDlgButtonChecked(hDlg, IDC_CHECK_AUTO_START);

	gbStartDisabled = (BOOL)IsDlgButtonChecked(hDlg, IDC_CHECK_START_DISABLED);

	gnFirstCheck = GetDlgItemInt(hDlg, IDC_EDIT_FIRST_CHECK, NULL, FALSE);

	gnDaysToForcedUpdate = GetDlgItemInt(hDlg, IDC_EDIT_FORCE_UPDATE_AFTER, NULL, FALSE);

	nIdx = SendDlgItemMessage(hDlg, IDC_COMBO_SLEEP, CB_GETCURSEL, 0, 0);
	guSleepTime = SleepTimes[nIdx].nDelay;

	guConnection = SendDlgItemMessage(hDlg, IDC_COMBO_CONNECTION, CB_GETCURSEL, 0, 0);

	uIface = SendDlgItemMessage(hDlg, IDC_COMBO_INTERFACE, CB_GETCURSEL, 0, 0);
	if (uIface != -1) {
		guInterface = uIface;
	}

	gbIsDynDNSDonator = (BOOL)IsDlgButtonChecked(hDlg, IDC_CHECK_DONATOR);

	GetDlgItemText(hDlg, IDC_EDIT_OFFLINE_IP, gszOfflineIP, sizeof(gszOfflineIP));

	gbUseProxy = (BOOL)IsDlgButtonChecked(hDlg, IDC_CHECK_USE_PROXY);

	GetDlgItemText(hDlg, IDC_EDIT_PROXY_SERVER, gszProxyServer, sizeof(gszProxyServer));

	gnProxyPortNr = GetDlgItemInt(hDlg, IDC_EDIT_PROXY_PORT, NULL, FALSE);

//	gbUseBasicAuth = (BOOL)IsDlgButtonChecked(hDlg, IDC_CHECK_USE_AUTHENTICATION);

//	GetDlgItemText(hDlg, IDC_EDIT_PROXY_USER, gszProxyUser, sizeof(gszProxyUser));

//	GetDlgItemText(hDlg, IDC_EDIT_PROXY_PASSWORD, gszProxyPassword, sizeof(gszProxyPassword));

	gbVersionCheck = (BOOL)IsDlgButtonChecked(hDlg, IDC_CHECK_VERSION_CHECK);

	gbDetailedLogging = (BOOL)IsDlgButtonChecked(hDlg, IDC_CHECK_DETAILED_LOGGING);
}


void PropDlgFillLists(HWND hDlg)
{
	struct SleepTimeType *stt;
	int nIdx;
	// Sleep times
	stt = SleepTimes;
	SendDlgItemMessage(hDlg, IDC_COMBO_SLEEP, CB_RESETCONTENT, 0, 0);

	while (stt->szText) {
		_snprintf( gszTextBuf, sizeof(gszTextBuf) - 1, GetString(stt->res), stt->szText);							// B.A.
		nIdx = SendDlgItemMessage(hDlg, IDC_COMBO_SLEEP, CB_ADDSTRING, 0, (DWORD)((LPSTR)gszTextBuf));
		SendDlgItemMessage(hDlg, IDC_COMBO_SLEEP, CB_SETITEMDATA, nIdx, (DWORD)stt->nDelay);
		stt++;
	}

	// Connection type
	SendDlgItemMessage(hDlg, IDC_COMBO_CONNECTION, CB_RESETCONTENT, 0, 0);

	nIdx = SendDlgItemMessage(hDlg, IDC_COMBO_CONNECTION, CB_ADDSTRING, 0, (DWORD)GetString(IDS_DLG_MODEM));
	SendDlgItemMessage(hDlg, IDC_COMBO_CONNECTION, CB_SETITEMDATA, nIdx, (DWORD)0);

	nIdx = SendDlgItemMessage(hDlg, IDC_COMBO_CONNECTION, CB_ADDSTRING, 0, (DWORD)GetString(IDS_DLG_LAN));
	SendDlgItemMessage(hDlg, IDC_COMBO_CONNECTION, CB_SETITEMDATA, nIdx, (DWORD)1);

	nIdx = SendDlgItemMessage(hDlg, IDC_COMBO_CONNECTION, CB_ADDSTRING, 0, (DWORD)GetString(IDS_DLG_WEBBASED));
	SendDlgItemMessage(hDlg, IDC_COMBO_CONNECTION, CB_SETITEMDATA, nIdx, (DWORD)2);
}


BOOL AccDlgIsUpdate(ACCINFO *ai, int *pnIdx)
{
	for (int i=0; i<gnAccountCount; i++) {
		if ((ai->aServer == AccountInfos[i].aServer) && (!stricmp(ai->szHostName, AccountInfos[i].szHostName))) {
			if (pnIdx) *pnIdx = i;
			return TRUE;
		}
	}

	if (pnIdx) *pnIdx = -1;
	return FALSE;
}


void AccDlgUpdateButtonStates(HWND hDlg)
{
	ACCINFO ai;
	HWND hWnd;
	char *szRequest;

	UpdateAccount(&ai, hDlg);

	if (ai.aServer) {
		szRequest = (ai.aServer)->aService->szRequest;
	} else {
		szRequest = NULL;
	}

	hWnd = GetDlgItem(hDlg, IDC_BUTTON_NEW);
	EnableWindow(hWnd, ((ai.aServer) && ((ai.aServer)->aService->szNewHostURL)));

	hWnd = GetDlgItem(hDlg, IDC_CHECK_WILDCARDS);
	EnableWindow(hWnd, (szRequest && strstr(szRequest, "###WILDCARD###")));

	hWnd = GetDlgItem(hDlg, IDC_EDIT_MAILEXT);
	EnableWindow(hWnd, (szRequest && strstr(szRequest, "###MAILEXT###")));

	hWnd = GetDlgItem(hDlg, IDC_CHECK_BACKUPMX);
	EnableWindow(hWnd, (szRequest && strstr(szRequest, "###BACKUPMX###")));

	// Are all the required fields filled?
	BOOL bOk = (*ai.szHostName && *ai.szUserName && *ai.szPassword);
	hWnd = GetDlgItem(hDlg, IDC_BUTTON_ADD);
	EnableWindow(hWnd, bOk);
	if (bOk) {
		if (AccDlgIsUpdate(&ai, NULL)) {
			SetDlgItemText(hDlg, IDC_BUTTON_ADD, (LPCTSTR)GetString(IDS_DLG_UPDATE));
		} else {
			SetDlgItemText(hDlg, IDC_BUTTON_ADD, (LPCTSTR)GetString(IDS_DLG_ADD));
		}
	}

	int nIdx = SendDlgItemMessage(hDlg, IDC_LIST_ACCOUNTS, LB_GETCURSEL, 0, 0);
	hWnd = GetDlgItem(hDlg, IDC_BUTTON_DELETE);
	EnableWindow(hWnd, (BOOL)(nIdx >= 1));
}


void AccDlgSetButtonStates(HWND hDlg)
{
	HWND hWnd;

	SendDlgItemMessage(hDlg, IDC_LIST_ACCOUNTS, LB_RESETCONTENT, 0, 0);
	SendDlgItemMessage(hDlg, IDC_LIST_ACCOUNTS, LB_ADDSTRING, 0, (DWORD)((LPSTR)GetString(IDS_DLG_ADDNEWACCT)));
	for (int i=0; i<gnAccountCount; i++) {
		char szName[2*MAXLEN_HOST_NAME + 2];
		ACCINFO *pai = AccountInfos + i;
		DNSServersType *aSrv = AccountInfos[i].aServer;

		strcpy(szName, pai->szHostName);
		if ((aSrv->nFlags & SRVTF_CUSTOM_DOMAIN) == 0) {
			strcat(szName, ".");
			strcat(szName, aSrv->szName);
		}
		if (!pai->bUpdate) {
			strcat(szName, GetString(IDS_DLG_DISABLED));
		}
		SendDlgItemMessage(hDlg, IDC_LIST_ACCOUNTS, LB_ADDSTRING, 0, (DWORD)((LPSTR)szName));
	}

	ACCINFO ai;
	memset(&ai, 0, sizeof(ACCINFO));
	ai.uOldServer = -1;
	SelectAccount(&ai, hDlg);

	CheckDlgButton(hDlg, IDC_CHECK_UPDATE, BST_CHECKED);

	hWnd = GetDlgItem(hDlg, IDC_BUTTON_ADD);
	EnableWindow(hWnd, FALSE);
	hWnd = GetDlgItem(hDlg, IDC_BUTTON_DELETE);
	EnableWindow(hWnd, FALSE);
}


void AccDlgGetButtonStates(HWND hDlg)
{
}


void SelectAccount(ACCINFO *ai, HWND hDlg)
{
	CheckDlgButton(hDlg, IDC_CHECK_UPDATE, ((ai && !ai->bUpdate) ? BST_UNCHECKED : BST_CHECKED));

	WORD nSrvIdx;
	if (ai) {
		nSrvIdx = (ai->aServer - DNSServers);
		SendDlgItemMessage(hDlg, IDC_COMBO_SERVERS, CB_SETCURSEL, nSrvIdx, 0);
	}

	SetDlgItemText(hDlg, IDC_EDIT_HOST_NAME, (ai) ? ai->szHostName : "");
	SendDlgItemMessage(hDlg, IDC_EDIT_HOST_NAME, EM_SETLIMITTEXT, MAXLEN_HOST_NAME, 0);

	SetDlgItemText(hDlg, IDC_EDIT_USER_NAME, (ai) ? ai->szUserName : "");
	SendDlgItemMessage(hDlg, IDC_EDIT_USER_NAME, EM_SETLIMITTEXT, MAXLEN_USER_NAME, 0);

	SetDlgItemText(hDlg, IDC_EDIT_PASSWORD, (ai) ? ai->szPassword : "");
	SendDlgItemMessage(hDlg, IDC_EDIT_PASSWORD, EM_SETLIMITTEXT, MAXLEN_PASSWORD, 0);

	CheckDlgButton(hDlg, IDC_CHECK_WILDCARDS, ((ai && ai->bWildcards) ? BST_CHECKED : BST_UNCHECKED));

	SetDlgItemText(hDlg, IDC_EDIT_MAILEXT, (ai) ? ai->szMailExt : "");
	SendDlgItemMessage(hDlg, IDC_EDIT_MAILEXT, EM_SETLIMITTEXT, MAXLEN_MAILEXT, 0);

	CheckDlgButton(hDlg, IDC_CHECK_BACKUPMX, ((ai && ai->bBackupMx) ? BST_CHECKED : BST_UNCHECKED));

	SetDlgItemText(hDlg, IDC_STATIC_STATUS, (ai) ? ai->szLastUpdateMsg : "");

	AccDlgUpdateButtonStates(hDlg);
}


void UpdateAccount(ACCINFO *ai, HWND hDlg)
{

	ai->bUpdate = (BOOL)IsDlgButtonChecked(hDlg, IDC_CHECK_UPDATE);
	ai->uSleep = 0;

	LONG lSrvIdx = SendDlgItemMessage(hDlg, IDC_COMBO_SERVERS, CB_GETCURSEL, 0, 0);
	if (lSrvIdx >= 0) {
		ai->aServer = DNSServers + lSrvIdx;
		strcpy(ai->szServer, ai->aServer->szName);	// Not really needed but the field is there so let's fill it, just to be sure
	} else {
		ai->aServer = NULL;
	}
	ai->uOldServer = lSrvIdx;	// Just here for possible backward compatibility with old account info

	GetDlgItemText(hDlg, IDC_EDIT_HOST_NAME, ai->szHostName, sizeof(ai->szHostName));

	GetDlgItemText(hDlg, IDC_EDIT_USER_NAME, ai->szUserName, sizeof(ai->szUserName));

	GetDlgItemText(hDlg, IDC_EDIT_PASSWORD, ai->szPassword, sizeof(ai->szPassword));

	ai->bWildcards = (BOOL)IsDlgButtonChecked(hDlg, IDC_CHECK_WILDCARDS);

	GetDlgItemText(hDlg, IDC_EDIT_MAILEXT, ai->szMailExt, sizeof(ai->szMailExt));

	ai->bBackupMx = (BOOL)IsDlgButtonChecked(hDlg, IDC_CHECK_BACKUPMX);

	GetDlgItemText(hDlg, IDC_STATIC_STATUS, ai->szLastUpdateMsg, sizeof(ai->szLastUpdateMsg));
}


void AccDlgFillLists(HWND hDlg)
{
	SERVINFO *ds;
	int nIdx, i;

	i = 0;
	ds = DNSServers;
	SendDlgItemMessage(hDlg, IDC_COMBO_SERVERS, CB_RESETCONTENT, 0, 0);
	while (ds->szName) {
		nIdx = SendDlgItemMessage(hDlg, IDC_COMBO_SERVERS, CB_ADDSTRING, 0, (DWORD)((LPSTR)ds->szName));
		SendDlgItemMessage(hDlg, IDC_COMBO_SERVERS, CB_SETITEMDATA, nIdx, (DWORD)i);
		ds++;
		i++;
	}
}


BOOL AccountInputOK(HWND hDlg)
{
	char szHostName[MAXLEN_HOST_NAME+1];

	HWND hWnd = GetDlgItem(hDlg, IDC_EDIT_HOST_NAME);
	LONG lSrvIdx = SendDlgItemMessage(hDlg, IDC_COMBO_SERVERS, CB_GETCURSEL, 0, 0);

	GetDlgItemText(hDlg, IDC_EDIT_HOST_NAME, szHostName, sizeof(szHostName));
	// TODO: Should try to find out which characters are legal in a host name
	if (strchr(szHostName, '.')) {
		if ((DNSServers[lSrvIdx].nFlags & SRVTF_CUSTOM_DOMAIN) == 0) {
			LoadString(ghLangDepRes, IDS_MSG_DOMTITLE, gszTextBuf, sizeof(gszTextBuf));
			MessageBox(NULL, GetString(IDS_MSG_DOMTEXT), gszTextBuf, MB_OK + MB_ICONWARNING);
			SetFocus(hWnd);
			return FALSE;
		}
	} else {
		if ((DNSServers[lSrvIdx].nFlags & SRVTF_CUSTOM_DOMAIN) != 0) {
			LoadString(ghLangDepRes, IDS_MSG_HOSTTITLE, gszTextBuf, sizeof(gszTextBuf));
			MessageBox(NULL, GetString(IDS_MSG_HOSTTEXT), gszTextBuf, MB_OK + MB_ICONWARNING);
			SetFocus(hWnd);
			return FALSE;
		}
	}

	return TRUE;
}


void SetAccountMsg(ACCINFO *ai, char *szMsg)
{
	if (ai) {
		strcpy(ai->szLastUpdateMsg, szMsg);
		if (ghAccDlg) {
			LONG nIdx = SendDlgItemMessage(ghAccDlg, IDC_LIST_ACCOUNTS, LB_GETCURSEL, 0, 0);
			if ((nIdx > 0) && ((AccountInfos + nIdx - 1) == ai)) {
				SetDlgItemText(ghAccDlg, IDC_STATIC_STATUS, (ai) ? ai->szLastUpdateMsg : "");
			}
		}
	}
}


void DoSnooze()
{
	gbErrorOccurred = FALSE;
	SetAnimationTimer(FALSE);
	SetState(ghwndMain, STATE_IDLE, NULL);
}


void DoShowHelp()
{
	ShellExecute(ghwndMain, "open", DEF_HELP_URL, NULL, NULL, SW_SHOWNORMAL);
}


void DoShowNewHost(HWND hDlg)
{
	ACCINFO ai;

	UpdateAccount(&ai, hDlg);
	if (ai.aServer) {
		char *szURL = (ai.aServer)->aService->szNewHostURL;
		if (szURL) {
			ShellExecute(ghwndMain, "open", szURL, NULL, NULL, SW_SHOWNORMAL);
		}
	}
}


void DoShowLogDlg2(BOOL bShow)
{
	if (!ghLogDlg) {
		ghLogDlg = CreateDialog(ghLangDepRes, MAKEINTRESOURCE(IDD_LOG), NULL, LogDlgProc2);
	}
	if (bShow) {
		ShowWindow(ghLogDlg, SW_SHOW);
	}
}

void DoShowPropDlg()
{
	if (!ghPropDlg) {
		ghPropDlg = CreateDialog(ghLangDepRes, MAKEINTRESOURCE(IDD_PROPERTIES), NULL, PropertyDlgProc);
	}
	ShowWindow(ghPropDlg, SW_SHOW);
}


void DoShowAccountsDlg()
{
	if (!ghAccDlg) {
		ghAccDlg = CreateDialog(ghLangDepRes, MAKEINTRESOURCE(IDD_ACCOUNTS), NULL, AccountsDlgProc);
	}
	ShowWindow(ghAccDlg, SW_SHOW);
}


void DoShowAboutDlg()
{
	if (!ghAboutDlg) {
		ghAboutDlg = CreateDialog(ghLangDepRes, MAKEINTRESOURCE(IDD_ABOUT), NULL, AboutDlgProc);
	}
	ShowWindow(ghAboutDlg, SW_SHOW);
}

void DoEnable()
{
	UINT uRes;

	StateChange(ghwndMain, 0);
	uRes = SetTimer(ghwndMain, TIMER_SLEEP, 1000, NULL);	// The first check will always be done after 1 second
	if (gbVersionCheck) {
		uRes = SetTimer(ghwndMain, TIMER_VERSION, versionWait(), NULL);	// The first check will always be done after 2 seconds
	}
	SetAnimationTimer(gbErrorOccurred);
	AddLogItem(ALI_DETAIL + ALI_DEBUG, GetString(IDS_LOG_DEENSENABLED));
}


void DoDisable()
{
	StateChange(ghwndMain, 1);
	KillTimer(ghwndMain, TIMER_SLEEP);
	KillTimer(ghwndMain, TIMER_VERSION);
	SetAnimationTimer(FALSE);
	AddLogItem(ALI_DETAIL + ALI_DEBUG, GetString(IDS_LOG_DEENSDISABLED));
}


void ResetTimers()
{
	KillTimer(ghwndMain, TIMER_SLEEP);
	KillTimer(ghwndMain, TIMER_VERSION);
	UINT uSleep = MinSleepTime();
	UINT uRes = SetTimer(ghwndMain, TIMER_SLEEP, uSleep, NULL);
	if (gbVersionCheck) {
		uRes = SetTimer(ghwndMain, TIMER_VERSION, versionWait(), NULL);
	}
	AddLogItem(ALI_DEBUG, GetString(IDS_LOG_TIMERRESET));
}


void AddLogFileItem(const char *szText)
{
/*	if (_Module.m_bService)
	{
		_Module.LogEvent(szText);
	}
	else {
*/		DWORD lWritten;

	HANDLE hLogFile = CreateFile(gszLogFile, GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, 0, NULL);
	if (hLogFile != INVALID_HANDLE_VALUE) {
		SetFilePointer(hLogFile, 0, 0, FILE_END);
		WriteFile(hLogFile, szText, strlen(szText), &lWritten, NULL);
		WriteFile(hLogFile, "\r\n", 2, &lWritten, NULL);
		CloseHandle(hLogFile);
	}
//	}
}


void AddLogItem(int nType, const char *szText, const char *szText2, const char *szText3, const char *szText4, const char *szText5)
{
    //BA This can be simplyfied to "void AddLogItem(int nType, const char *szText) {" and so can the following code..
	char *szBuf;
	long lSize;
	int nIdx;
	struct tm *tmNow;
	time_t tNow;

	// This is just here temporarily until I've made an option to turn this on/off
	if (((nType & ALI_DETAIL) || (nType & ALI_DEBUG)) && !gbDetailedLogging) {
		return;
	}

	if (!ghLogDlg) {
		DoShowLogDlg2(FALSE);
	}

	lSize = strlen(szText);
	if (szText2) {
		lSize += strlen(szText2);
	}
	if (szText3) {
		lSize += strlen(szText3);
	}
	if (szText4) {
		lSize += strlen(szText4);
	}
	if (szText5) {
		lSize += strlen(szText5);
	}
	szBuf = (char *)malloc(lSize + 128);
	if (!szBuf) {
		return;
	}

	time(&tNow);
	tmNow = localtime(&tNow);
	strftime(szBuf, 128,"%c", tmNow);

	strcat(szBuf, ": ");
	if (nType & ALI_DETAIL) {
		strcat(szBuf, "   ");
	}
	if (nType & ALI_ERROR) {
		strcat(szBuf, "*** ");
	}
	strcat(szBuf, szText);
	if (szText2) {
		strcat(szBuf, " ");
		strcat(szBuf, szText2);
	}
	if (szText3) {
		strcat(szBuf, " ");
		strcat(szBuf, szText3);
	}
	if (szText4) {
		strcat(szBuf, " ");
		strcat(szBuf, szText4);
	}
	if (szText5) {
		strcat(szBuf, " ");
		strcat(szBuf, szText5);
	}

	if (nType & ALI_DEBUG) {
		DbgMsg("\r\n");
		DbgMsg(szBuf);
	}
	AddLogFileItem(szBuf);

	if (nType != ALI_DEBUG) {
		nIdx = SendDlgItemMessage(ghLogDlg, IDC_LIST_LOG, LB_ADDSTRING, 0, (DWORD)((LPSTR)szBuf));
		SendDlgItemMessage(ghLogDlg, IDC_LIST_LOG, LB_SETTOPINDEX, nIdx, 0);
	}

	free(szBuf);
}


//---------------------------------------------------------------------------
// DeeEnEsWndProc
//
// Window procedure for the application's dialog.
//
//---------------------------------------------------------------------------

int CALLBACK DeeEnEsWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	HDC hDC;
	LRESULT lRes = 0;

	switch(uMsg) {	
		case WM_PAINT:
			hDC = BeginPaint(ghwndMain, &ps);
			EndPaint(ghwndMain, &ps);
			break;

		case WM_DRAWITEM:
			return(IconDrawItem((LPDRAWITEMSTRUCT)lParam));
			break;

		case WM_DESTROY:
			PostQuitMessage(0);
			break;

		case WM_COMMAND:
			switch (GET_WM_COMMAND_ID(wParam, lParam)) {
				case IDM_EXIT:
					PostQuitMessage(0);
					break;

				case IDM_ABOUT:
					DoShowAboutDlg();
					break;

				case IDM_HELP:
					DoShowHelp();
					break;

				case IDM_DISABLE:
					if (gbDisabled) {
						DoEnable();
					} else {
						DoDisable();
					}
					break;

				case IDM_VIEW_LOG:
					DoShowLogDlg2(TRUE);
					break;

				case IDM_ACCOUNTS:
					DoShowAccountsDlg();
					break;

				case IDM_PROPERTIES:
					DoShowPropDlg();
					break;

				case IDM_CHECKNOW:
					KillTimer(ghwndMain, TIMER_SLEEP);
					KillTimer(ghwndMain, TIMER_VERSION);
					AddLogItem(ALI_INFO, GetString(IDS_LOG_MANUALUPDATE));
					UpdateAllDNS(UPDATE_MANUAL);
					if (gbVersionCheck) {
						CheckVersion(UPDATE_MANUAL);
					}
					break;

				case IDM_FORCE_UPDATE:
					char szTxt[1024];
					if (LoadString(ghLangDepRes, IDS_FORCE_UPDATE_WARNING, szTxt, sizeof(szTxt))) {
						if (MessageBox(NULL, szTxt, GetString(IDS_FORCE_UPDATE_WARNING_TITLE), MB_YESNO + MB_ICONWARNING) == IDYES) {
							UpdateAllDNS(UPDATE_FORCE);
						}
					}
					break;

				case IDM_SNOOZE:
					DoSnooze();
					break;

				case IDM_OFFLINE:
					UpdateAllDNS(OFFLINE_MANUAL);
					break;
			}
			break;

		case WM_TIMER:
			switch (wParam) {
				case TIMER_SLEEP:
					// add icon to the shell if needed
					NotifyChange(ghwndMain);
					KillTimer(ghwndMain, TIMER_SLEEP);
					UpdateAllDNS(UPDATE_AUTO);
					break;

				case TIMER_VERSION:
					KillTimer(ghwndMain, TIMER_VERSION);
					if (gbVersionCheck) {
						CheckVersion(UPDATE_AUTO);
					}
					break;

				case TIMER_ANIM:
					if (guFlashIcon == IDI_ICON_TRAY_ON) {
						guFlashIcon = IDI_ICON_TRAY_ERROR;
					} else {
						guFlashIcon = IDI_ICON_TRAY_ON;
					}
					SetState(hWnd, STATE_FLASHING, NULL);
					break;
			}
			break;

		case MYWM_NOTIFYICON:
			switch (lParam) {
				case WM_LBUTTONDBLCLK:
					DoShowLogDlg2(TRUE);
					if (gbErrorOccurred) {
						SetState(ghwndMain, STATE_IDLE, NULL);
						SetAnimationTimer(false);
						gbErrorOccurred = FALSE;
					}
					break;

				case WM_RBUTTONDOWN:
					HandleMenu(hWnd);
					if (gbErrorOccurred) {
						SetState(ghwndMain, STATE_IDLE, NULL);
						SetAnimationTimer(false);
						gbErrorOccurred = FALSE;
					}
					break;
			}
			break;

		default:
			lRes = DefWindowProc(hWnd, uMsg, wParam, lParam);
	}

	return lRes;
}


//---------------------------------------------------------------------------
// LogDlgProc
//
// Window procedure for the application's dialog.
//
//---------------------------------------------------------------------------

int CALLBACK LogDlgProc2(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg) {	
		case WM_INITDIALOG:
			ghLogDlg = hDlg;
			SetDlgItemText(hDlg, IDC_EDIT_SHOWIP, inet_ntoa(*((IN_ADDR *)&glCurrentIP)));
			break;

		case WM_COMMAND:
			switch (GET_WM_COMMAND_ID(wParam, lParam)) {
				case IDOK:
				case IDCANCEL:
					ShowWindow(hDlg, SW_HIDE);
					break;
			}
			break;

		case WM_ACTIVATE:
			if (0 == wParam)             // becoming inactive
				ghDlgCurrent = NULL;
			else                         // becoming active
				ghDlgCurrent = hDlg;
			break;
		 
		case WM_DESTROY:
			ghLogDlg = 0;
			break;

		default:
			return FALSE;
	}

	return TRUE;
}


//---------------------------------------------------------------------------
// PropertyDlgProc
//
// Window procedure for the application's dialog.
//
//---------------------------------------------------------------------------

int CALLBACK PropertyDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	UINT uConn;

	switch(uMsg) {	
		case WM_INITDIALOG:
			ghPropDlg = hDlg;
			KillTimer(ghwndMain, TIMER_SLEEP);
			KillTimer(ghwndMain, TIMER_VERSION);
			PropDlgFillLists(hDlg);
			PropDlgSetButtonStates(hDlg);
			SetForegroundWindow(hDlg);
			break;

		case WM_COMMAND:
			switch (GET_WM_COMMAND_ID(wParam, lParam)) {
				case IDC_COMBO_CONNECTION:
					uConn = SendDlgItemMessage(hDlg, IDC_COMBO_CONNECTION, CB_GETCURSEL, 0, 0);
					if (uConn != guConnection) {
						guConnection = uConn;
						FillInterfaceWebList(hDlg, IDC_COMBO_INTERFACE);
					}
					break;

				case IDC_CHECK_USE_PROXY:
				case IDC_CHECK_USE_AUTHENTICATION:
					PropDlgUpdateButtonStates(hDlg);
					break;

				case IDC_CHECK_DETAILED_LOGGING:
					if ((BOOL)IsDlgButtonChecked(hDlg, IDC_CHECK_DETAILED_LOGGING)) {
						LoadString(ghLangDepRes, IDS_MSG_DEBUGTITLE, gszTextBuf, sizeof(gszTextBuf));
						MessageBox(NULL, GetString(IDS_MSG_DEBUGTEXT), gszTextBuf, MB_OK + MB_ICONWARNING);
					}
					break;

				case IDOK:
					PropDlgGetButtonStates(hDlg);
					SaveSettings();
					DestroyWindow(hDlg);
					break;

				case IDCANCEL:
					LoadSettings();
					NotifyChange(ghwndMain);
					DestroyWindow(hDlg);
					break;
			}
			break;

		case WM_ACTIVATE:
			if (0 == wParam)             // becoming inactive
				ghDlgCurrent = NULL;
			else                         // becoming active
				ghDlgCurrent = hDlg;
			break;
		 
		case WM_DESTROY:
			ResetTimers();
			ghPropDlg = 0;
			break;

		default:
			return FALSE;
	}

	return TRUE;
}


//---------------------------------------------------------------------------
// AccountsDlgProc
//
// Window procedure for the application's dialog.
//
//---------------------------------------------------------------------------

int CALLBACK AccountsDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	int nIdx;

	switch(uMsg) {	
		case WM_INITDIALOG:
			ghAccDlg = hDlg;
			KillTimer(ghwndMain, TIMER_SLEEP);
			KillTimer(ghwndMain, TIMER_VERSION);
			AccDlgFillLists(hDlg);
			AccDlgSetButtonStates(hDlg);
			SetForegroundWindow(hDlg);
			break;

		case WM_COMMAND:
			switch (GET_WM_COMMAND_ID(wParam, lParam)) {
				case IDC_LIST_ACCOUNTS:
					switch (GET_WM_COMMAND_CMD(wParam, lParam)) {
						case LBN_SELCHANGE:
							nIdx = SendDlgItemMessage(hDlg, IDC_LIST_ACCOUNTS, LB_GETCURSEL, 0, 0);
							if (nIdx > 0) {
								SelectAccount(AccountInfos + nIdx - 1, hDlg);
							} else {
								SelectAccount(NULL, hDlg);
							}
							break;
					}
					break;

				case IDC_COMBO_SERVERS:
					switch (GET_WM_COMMAND_CMD(wParam, lParam)) {
						case CBN_SELCHANGE:
							AccDlgUpdateButtonStates(hDlg);
							break;
					}
					break;

				case IDC_BUTTON_NEW:
					DoShowNewHost(hDlg);
					break;

				case IDC_EDIT_HOST_NAME:
				case IDC_EDIT_USER_NAME:
				case IDC_EDIT_PASSWORD:
					switch (GET_WM_COMMAND_CMD(wParam, lParam)) {
						case EN_UPDATE:
							AccDlgUpdateButtonStates(hDlg);
							break;
					}
					break;

				case IDC_BUTTON_ADD:
					ACCINFO ai;

					if (AccountInputOK(hDlg)) {
						UpdateAccount(&ai, hDlg);
						if (AccDlgIsUpdate(&ai, &nIdx)) {
							AccountInfos[nIdx] = ai;
						} else {
							AccountInfos[gnAccountCount++] = ai;
						}
						AccDlgSetButtonStates(hDlg);
					}
					break;

				case IDC_BUTTON_DELETE:
					nIdx = SendDlgItemMessage(hDlg, IDC_LIST_ACCOUNTS, LB_GETCURSEL, 0, 0);
					if (nIdx > 0) {
						nIdx--;				// Normalize index (list select index count from 1, the account info array from 0)
						gnAccountCount--;	// One less acount
						if (nIdx < gnAccountCount) {
							memmove(AccountInfos+nIdx, AccountInfos+nIdx+1, (gnAccountCount - nIdx) * sizeof(ACCINFO));
						}
						AccDlgSetButtonStates(hDlg);
					}
					break;

				case IDOK:
					AccDlgGetButtonStates(hDlg);
					CreateAccRegInfo(&accbag, true);
					SaveSettings();
					DestroyWindow(hDlg);
					break;

				case IDCANCEL:
					LoadSettings();
					DestroyWindow(hDlg);
					break;
			}
			break;

		case WM_ACTIVATE:
			if (0 == wParam)             // becoming inactive
				ghDlgCurrent = NULL;
			else                         // becoming active
				ghDlgCurrent = hDlg;
			break;
		 
		case WM_DESTROY:
			ghAccDlg = 0;
			ResetTimers();
			break;

		default:
			return FALSE;
	}

	return TRUE;
}


//---------------------------------------------------------------------------
// AboutDlgProc
//
// Window procedure for the application's dialog.
//
//---------------------------------------------------------------------------

int CALLBACK AboutDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	char szBuf[128];

	switch(uMsg) {	
		case WM_INITDIALOG:
			ghAboutDlg = hDlg;
            LoadString(ghLangDepRes, IDS_DNS_NAME, szBuf, sizeof(szBuf));
			strcat(szBuf, " ");
			strcat(szBuf, GetDNSVersion());
			SetDlgItemText(hDlg, IDC_PRODUCT, (LPCTSTR)szBuf);
			break;

		case WM_COMMAND:
			switch (GET_WM_COMMAND_ID(wParam, lParam)) {
				case IDOK:
				case IDCANCEL:
					DestroyWindow(hDlg);
					break;
			}
			break;

		case WM_ACTIVATE:
			if (0 == wParam)             // becoming inactive
				ghDlgCurrent = NULL;
			else                         // becoming active
				ghDlgCurrent = hDlg;
			break;
		 
		case WM_DESTROY:
			ghAboutDlg = 0;
			break;

		default:
			return FALSE;
	}

	return TRUE;
}


//---------------------------------------------------------------------------
// WizDlgProc
//
// Window procedure for the application's wizard dialog.
//
//---------------------------------------------------------------------------

int CALLBACK WizDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static LPARAM lDialogId;
	HWND hChildWnd;
	int nId;

	switch(uMsg) {	
		case WM_INITDIALOG:
			lDialogId = lParam;
			switch (lDialogId) {
				case IDD_DIALOG_CONNECTION:
					if (guConnection == CONN_MODEM) {
						SendDlgItemMessage(hDlg, IDC_WIZ_RADIO_MODEM, BM_CLICK, 0, 0);
					} else {
						SendDlgItemMessage(hDlg, IDC_WIZ_RADIO_LAN, BM_CLICK, 0, 0);
					}
					break;
				case IDD_DIALOG_USER:
					hChildWnd = GetDlgItem(hDlg, IDC_WIZ_EDIT_USER);
//					SetWindowText(hChildWnd, gszUserName);
					hChildWnd = GetDlgItem(hDlg, IDC_WIZ_EDIT_PASSWORD);
//					SetWindowText(hChildWnd, gszPassword);
					break;
			}
//			gbWizDlgShown = TRUE;
			break;

		case WM_COMMAND:
			nId = GET_WM_COMMAND_ID(wParam, lParam);
			switch (nId) {
				case IDCANCEL:
					EndDialog(hDlg, IDCANCEL);
					break;
				case IDOK:
				case IDC_BUTTON_BACK:
				case IDC_BUTTON_NEXT:
					switch (lDialogId) {
						case IDD_DIALOG_CONNECTION:
							if (IsDlgButtonChecked(hDlg, IDC_WIZ_RADIO_MODEM)) {
								guConnection = CONN_MODEM;
							} else {
								guConnection = CONN_LAN;
							}
							break;
						case IDD_DIALOG_USER:
							hChildWnd = GetDlgItem(hDlg, IDC_WIZ_EDIT_USER);
//							GetWindowText(hChildWnd, gszUserName, sizeof(gszUserName));
							hChildWnd = GetDlgItem(hDlg, IDC_WIZ_EDIT_PASSWORD);
//							GetWindowText(hChildWnd, gszPassword, sizeof(gszPassword));
							break;
					}
					EndDialog(hDlg, nId);
					break;
			}
			break;

		case WM_ACTIVATE:
			if (0 == wParam)             // becoming inactive
				ghDlgCurrent = NULL;
			else                         // becoming active
				ghDlgCurrent = hDlg;
			break;
		 
		case WM_DESTROY:
//			gbWizDlgShown = FALSE;
			break;

		default:
			return FALSE;
	}

	return TRUE;
}

