
/****************************************************************************
** DeeEnEs - Automatic Dynamic IP Updater
** Copyright (C) 2000, 2001, 2002, 2003, 2004 Tako Schotanus
** 
** This program is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License
** as published by the Free Software Foundation; either version 2
** of the License, or (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
****************************************************************************/

#include <windows.h>
#include "serverinfo.h"

#define DYNDNS_OLDREQUEST		"GET ###SERVER###/nic/dyndns?action=edit&started=1&hostname=YES&host_id=###HOST###&myip=###IP###&wildcard=###WILDCARD###&mx=###MAILEXT###&backmx=###BACKUPMX### HTTP/1.1\r\n"
#define DYNDNS_NEWREQUEST		"GET ###SERVER###/nic/update?system=dyndns&hostname=###HOST###&myip=###IP###&wildcard=###WILDCARD###&mx=###MAILEXT###&backmx=###BACKUPMX### HTTP/1.1\r\n"
#define DYNDNS_CUSTOMREQUEST	"GET ###SERVER###/nic/update?system=custom&hostname=###HOST###&myip=###IP###&wildcard=###WILDCARD###&mx=###MAILEXT###&backmx=###BACKUPMX### HTTP/1.1\r\n"
#define DYNDNS_OFFLINEREQUEST	"GET ###SERVER###/nic/update?system=dyndns&hostname=###HOST###&offline=YES HTTP/1.1\r\n"
#define DYNDNS_CUSTOMOFFLINEREQ	"GET ###SERVER###/nic/update?system=custom&hostname=###HOST###&offline=YES HTTP/1.1\r\n"
#define DSLREPORTS_REQUEST		"GET ###SERVER###/nic?action=edit&started=1&hostname=YES&host_id=###HOST###&myip=###IP###&wildcard=###WILDCARD### HTTP/1.1\r\n"


// This table is only to convert 2.1.15 and older account info to the new format
char *szOldDNSServerNames[SIZE_OLDSERVERNAMES + 1] = {
	"dyndns.org",
	"ath.cx",
	"shacknet.nu",
	"mine.nu",
	"merseine.nu",
	"homeip.net",
	"",	// itacs.to has been deprecated
	"dnsalias.com",
	"dnsalias.org",
	"dnsalias.net",
	"dslreports.com",
	NULL
};


struct DNSServicesType DNSServices[SIZE_SERVICES + 1] = {
	"DynDNS",				"members.dyndns.org", 80,	DYNDNS_NEWREQUEST,		DYNDNS_OFFLINEREQUEST,		PROT_DYNDNS_NEW,	"https://www.dyndns.org/services/dyndns/add.html",	SCETF_OFFLINE_DONATORS_ONLY,
	"DynDNS (custom)",		"members.dyndns.org", 80,	DYNDNS_CUSTOMREQUEST,	DYNDNS_CUSTOMOFFLINEREQ,	PROT_DYNDNS_NEW,	"https://www.dyndns.org/services/custom/add.html",	SCETF_OFFLINE_DONATORS_ONLY,
	"OrgDNS",				"members.orgdns.org", 80,	DYNDNS_NEWREQUEST,		NULL,						PROT_DYNDNS_NEW,	"http://members.orgdns.org/nic/create",				0,
	"DSL Reports",			"www.dslreports.com", 80,	DSLREPORTS_REQUEST,		NULL,						PROT_DYNDNS_OLD,	NULL,												0,
	NULL, NULL, 0, NULL, NULL, 0, NULL, 0
};


struct DNSServersType DNSServers[SIZE_SERVERS + 1] = {
	"<dyndns custom>",	DNSServices + 1, SRVTF_DONATORS_ONLY | SRVTF_CUSTOM_DOMAIN,
	"ath.cx",			DNSServices + 0, 0,
	"blogdns.com",		DNSServices + 0, 0,
	"blogdns.net",		DNSServices + 0, 0,
	"blogdns.org",		DNSServices + 0, 0,
	"dnsalias.com",		DNSServices + 0, 0,
	"dnsalias.net",		DNSServices + 0, 0,
	"dnsalias.org",		DNSServices + 0, 0,
	"dslreports.com",	DNSServices + 3, 0,
	"dynalias.com",		DNSServices + 0, 0,
	"dynalias.net",		DNSServices + 0, 0,
	"dynalias.org",		DNSServices + 0, 0,
	"dyndns.biz",		DNSServices + 0, 0,
	"dyndns.info",		DNSServices + 0, 0,
	"dyndns.org",		DNSServices + 0, 0,
	"dyndns.tv",		DNSServices + 0, 0,
	"dyndns.ws",		DNSServices + 0, 0,
	"game-host.org",	DNSServices + 0, 0,
	"game-server.cc",	DNSServices + 0, 0,
	"gotdns.com",		DNSServices + 0, 0,
	"gotdns.org",		DNSServices + 0, 0,
	"homedns.org",		DNSServices + 0, 0,
	"homeftp.net",		DNSServices + 0, 0,
	"homeftp.org",		DNSServices + 0, 0,
	"homeip.net",		DNSServices + 0, 0,
	"homelinux.com",	DNSServices + 0, 0,
	"homelinux.net",	DNSServices + 0, 0,
	"homelinux.org",	DNSServices + 0, 0,
	"homeunix.com",		DNSServices + 0, 0,
	"homeunix.net",		DNSServices + 0, 0,
	"homeunix.org",		DNSServices + 0, 0,
	"is-a-geek.com",	DNSServices + 0, 0,
	"is-a-geek.net",	DNSServices + 0, 0,
	"is-a-geek.org",	DNSServices + 0, 0,
	"isa-geek.com",		DNSServices + 0, 0,
	"isa-geek.net",		DNSServices + 0, 0,
	"isa-geek.org",		DNSServices + 0, 0,
	"kicks-ass.net",	DNSServices + 0, 0,
	"kicks-ass.org",	DNSServices + 0, 0,
	"merseine.nu",		DNSServices + 0, 0,
	"mine.nu",			DNSServices + 0, 0,
	"myphotos.cc",		DNSServices + 0, 0,
	"orgdns.org",		DNSServices + 2, 0,
	"serveftp.net",		DNSServices + 0, 0,
	"serveftp.org",		DNSServices + 0, 0,
	"servegame.org",	DNSServices + 0, 0,
	"shacknet.nu",		DNSServices + 0, 0,
	NULL, NULL, 0
};


struct WebIPDetectorType WebIPDetectors[SIZE_WEBIPDETECTORS + 1] = {
	"DynDNS",			"checkip.dyndns.org",	80,		"GET ###SERVER###/ HTTP/1.1\r\n",
	"DynDNS (high)",	"checkip.dyndns.org",	8245,	"GET ###SERVER###/ HTTP/1.1\r\n",
	"OrgDNS",			"members.orgdns.org",	80,		"GET ###SERVER###/nic/ip HTTP/1.1\r\n",
	NULL, NULL
};
