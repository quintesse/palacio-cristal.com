
/****************************************************************************
** DeeEnEs - Automatic Dynamic IP Updater
** Copyright (C) 2000, 2001, 2002, 2003, 2004 Tako Schotanus
** 
** This program is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License
** as published by the Free Software Foundation; either version 2
** of the License, or (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
****************************************************************************/

#define _WIN32_WINNT 0x0400
#define WINVER 0x0400

//#include <windows.h>
#include <Winsock2.h>
#include <Ws2tcpip.h>
#include <stdio.h>
#include "resource.h"
#include "DeeEnEs.h"

int EnumInterfaces(INTERFACE_INFO *localAddr)
{
	WORD versionRequested;
	int wsError;
	WSADATA winsockData; 
	SOCKET s;
	DWORD bytesReturned;

	versionRequested = MAKEWORD(2, 2);

	wsError = WSAStartup(versionRequested, &winsockData); 
	if (wsError) {
		return 0;
	}

	if ((s = WSASocket(AF_INET, SOCK_DGRAM, IPPROTO_UDP, NULL, 0, 0)) == INVALID_SOCKET) {
		WSACleanup();
		return 0;
   	}

	// Enumerate all IP interfaces
	wsError = WSAIoctl(s, SIO_GET_INTERFACE_LIST, NULL, 0, localAddr, 10 * sizeof(INTERFACE_INFO), &bytesReturned, NULL, NULL);
	if (wsError == SOCKET_ERROR) {
		closesocket(s);
		WSACleanup();
		return 0;
	}

	closesocket(s);

	WSACleanup();

	return (bytesReturned/sizeof(INTERFACE_INFO));
}

bool AddressOK(INTERFACE_INFO *ii)
{
	long lAddr;
	char resRTxt[MAXLEN_LANGOUTPUT];;  // Rescource Text-Buffer & Replaced TB B.A.
	if (!(ii->iiFlags & IFF_LOOPBACK)) {
		lAddr = ii->iiAddress.AddressIn.sin_addr.S_un.S_addr;
		if (((lAddr & 0x000000ff) == 0x0000000a)	// The 10/8 address range should be ignored
		|| ((lAddr & 0x0000f0ff) == 0x000010ac)		// The 172.16/12 address range should be ignored
		|| ((lAddr & 0x0000ffff) == 0x0000a8c0)) {	// The 192.168/16 address range should be ignored
			AddLogItem(ALI_DEBUG, "IP number", inet_ntoa(ii->iiAddress.AddressIn.sin_addr), "is in a private range and will be ignored");
			return false;
		}
		sprintf( resRTxt, GetString(IDS_LOG_IPNUM_ISOK), inet_ntoa(ii->iiAddress.AddressIn.sin_addr));
		AddLogItem(ALI_DEBUG, resRTxt);
		return true;
	} 
	sprintf( resRTxt, GetString(IDS_LOG_IPNUMISLOCAL), inet_ntoa(ii->iiAddress.AddressIn.sin_addr));
	AddLogItem(ALI_DEBUG, resRTxt);
	return false;
}

void FillInterfaceList(HWND hDlg, int nDlgItem)
{
	INTERFACE_INFO localAddr[10];  // Assume there will be no more than 10 IP interfaces 
	char* pAddrString;
	SOCKADDR_IN* pAddrInet;
	int numLocalAddr; 

	memset(localAddr, 0, 10 * sizeof(INTERFACE_INFO));
	numLocalAddr = EnumInterfaces(localAddr);

	SendDlgItemMessage(hDlg, nDlgItem, CB_RESETCONTENT, 0, 0);
	for (int i=0; i<numLocalAddr; i++) {
		if (AddressOK(localAddr + i)) {
			pAddrInet = (SOCKADDR_IN*)&localAddr[i].iiAddress;
			pAddrString = inet_ntoa(pAddrInet->sin_addr);
			if (pAddrString) {
				SendDlgItemMessage(hDlg, nDlgItem, CB_ADDSTRING, 0, (DWORD)((LPSTR)pAddrString));
			}
		}
	}
}

long GetIP(UINT uInterface)
{
	INTERFACE_INFO localAddr[10];  // Assume there will be no more than 10 IP interfaces 
	SOCKADDR_IN* pAddrInet;
	int numLocalAddr;
	long lRes = 0;

	numLocalAddr = EnumInterfaces(localAddr);

	for (int i=0; i<numLocalAddr; i++) {
		if (AddressOK(localAddr + i)) {
			pAddrInet = (SOCKADDR_IN*)&localAddr[i].iiAddress;
			lRes = pAddrInet->sin_addr.S_un.S_addr;
			if (!uInterface--) {
				break;
			}
		}
	}
	return lRes;
}
